import argparse

import torch

from training_runner.model_train import training

DEFAULT_BATCH_SIZE = 16
DEFAULT_EPOCHS = 15
DEFAULT_MODEL_PATH = "/tmp"
DEFAULT_MODEL_NAME = "best_model"
DEFAULT_BASE_VALUE = 'base'
DEFAULT_SEED = 1234
DEFAULT_LEARNING_RATE = 2e-5
DEFAULT_OUTPUT_ACTIVATION_TYPE = "softmax"
DEFAULT_BINARY_TARGET = ""
DEFAULT_SIGMOID_THRESHOLD = 0.5

parser = argparse.ArgumentParser(description='Create a classifier using BERT and data provided.')

required = parser.add_argument_group('required named arguments')
required.add_argument('--trainingData',
                      action="store",
                      dest='training_data_path',
                      required=True,
                      help='Training data path. Example: /data/dataset/d220/training')
required.add_argument('--testData',
                      action="store",
                      dest='test_data_path',
                      required=True,
                      help='Test data path. Example: /data/dataset/d220/test')
required.add_argument('--output',
                      action="store",
                      dest='output_path',
                      required=True,
                      help='The output path, example: /data/model/d220-01')
required.add_argument('--bertModel',
                      action="store",
                      dest='bert_model_path',
                      required=True,
                      help='bert model path. Example: /data/model/bert-base-cased')

optional = parser.add_argument_group('optional arguments')
optional.add_argument('--classifierModel',
                      action="store",
                      dest='existing_model_path',
                      help='Existing classifier model path to continue training. Example: /data/model/d220/')
optional.add_argument('--batchSize',
                      action="store",
                      dest='batch_size',
                      type=int,
                      help='Set batch size, default: {}'.format(DEFAULT_BATCH_SIZE),
                      default=DEFAULT_BATCH_SIZE)
optional.add_argument('--maxEpochs',
                      action="store",
                      dest='epochs',
                      type=int,
                      help='Set epochs, default: {}'.format(DEFAULT_EPOCHS),
                      default=DEFAULT_EPOCHS)
optional.add_argument('--modelName',
                      action="store",
                      dest='model_name',
                      help='Model name, default: {}'.format(DEFAULT_MODEL_NAME),
                      default=DEFAULT_MODEL_NAME)
optional.add_argument('--seed',
                      action="store",
                      dest='seed',
                      type=int,
                      help='Desired manual seed which is used in torch for generating random numbers, default: {}'
                      .format(DEFAULT_SEED),
                      default=DEFAULT_SEED)
optional.add_argument('--learningRate',
                      action="store",
                      dest='learning_rate',
                      type=float,
                      help='Set the desired learning rate for training, default : {}'
                      .format(DEFAULT_LEARNING_RATE),
                      default=DEFAULT_LEARNING_RATE)
optional.add_argument('--sigmoidThreshold',
                      action="store",
                      dest='sigmoid_threshold',
                      type=float,
                      help='Set the desired learning rate for training, default : {}'
                      .format(DEFAULT_SIGMOID_THRESHOLD),
                      default=DEFAULT_SIGMOID_THRESHOLD)
optional.add_argument('--outputActivationType',
                      action="store",
                      dest='output_activation_type',
                      help='Decide if the classes are mutually exclusive(softmax) or not (sigmoid), default : {}'
                      .format(DEFAULT_OUTPUT_ACTIVATION_TYPE),
                      default=DEFAULT_OUTPUT_ACTIVATION_TYPE)
optional.add_argument('--binaryTarget',
                      action="store",
                      dest='binary_target',
                      help='Set the desired positive label for binary classification, default : {}'
                      .format(DEFAULT_BINARY_TARGET),
                      default=DEFAULT_BINARY_TARGET)

if __name__ == "__main__":
    args = parser.parse_args()
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    training(batch_size=args.batch_size,
             epochs=args.epochs,
             test_data_path=args.test_data_path,
             training_data_path=args.training_data_path,
             output_path=args.output_path,
             bert_model_path=args.bert_model_path,
             existing_model_path=args.existing_model_path,
             model_name=args.model_name,
             learning_rate=args.learning_rate,
             output_activation_type=args.output_activation_type,
             binary_target=args.binary_target,
             sigmoid_threshold=args.sigmoid_threshold)
