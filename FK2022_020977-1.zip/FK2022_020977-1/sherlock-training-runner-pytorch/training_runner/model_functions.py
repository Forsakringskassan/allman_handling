import logging.config

import torch
from sklearn.metrics import classification_report

SOFTMAX = "softmax"
SIGMOID = "sigmoid"

MSG_MODEL_DOES_NOT_EXIST = 'Model file does not exist.'
MSG_MODEL_STATE_DOES_NOT_EXIST = 'The saved model does not have model_state_dict inside.'
MSG_MODEL_INCORRECT_STRUCTURE = 'The model saved is build with the different structure.'

logger = logging.getLogger(__name__)


def calculate_loss(data, device, model, loss_fct, output_activation_type):
    texts, masks, labels = data
    texts, masks = texts.to(device), masks.to(device)
    if output_activation_type == SOFTMAX:
        labels = labels.to(device)
    elif output_activation_type == SIGMOID:
        labels = labels.type(torch.FloatTensor).to(device)

    logits = model(input_ids=texts, attention_mask=masks)
    loss = loss_fct(logits, labels)
    return loss, len(texts)


def train(model, device, training_loader, loss_fct, optimizer, iteration, output_activation_type, eval_step=50):
    model.train()
    data_len = len(training_loader.dataset)
    running_loss = 0
    for batch_idx, _data in enumerate(training_loader):
        iteration += 1
        loss, text_len = calculate_loss(_data, device, model, loss_fct, output_activation_type)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        running_loss += loss.item()

        if batch_idx % eval_step == 0 or batch_idx == data_len:
            logger.info('Training Iteration: {} [{}/{} ({:.0f}%)]\tTraining Loss: {}'.format(
                iteration, batch_idx * text_len, data_len, 100. * batch_idx / len(training_loader), loss.item()))

    return iteration


def evaluation(model, device, test_loader, loss_fct, iteration, output_activation_type):
    model.eval()
    data_len = len(test_loader)
    with torch.no_grad():
        valid_running_loss = 0
        for batch_idx, _data in enumerate(test_loader):
            loss, _ = calculate_loss(_data, device, model, loss_fct, output_activation_type)
            valid_running_loss += loss.item()

        average_loss = valid_running_loss / data_len
        logger.info('Evaluate Iteration: {} \tEvaluation Loss: {}'.format(iteration, average_loss))

    return average_loss


def final_evaluation(model, device, test_loader, output_activation_type, label_names, type, threshold=0.5):
    pred_values = []
    true_values = []

    model.eval()
    with torch.no_grad():
        for _data in test_loader:

            texts, masks, labels = _data
            texts, masks = texts.to(device), masks.to(device)

            logits = model(input_ids=texts, attention_mask=masks)

            if output_activation_type == SOFTMAX:
                labels = labels.to(device)
                labels_pred = torch.argmax(logits, 1)
            elif output_activation_type == SIGMOID:
                labels = labels.type(torch.FloatTensor).to(device)
                labels_pred = torch.sigmoid(logits)
                labels_pred[labels_pred >= threshold] = 1
                labels_pred[labels_pred < threshold] = 0

            pred_values.extend(labels_pred.tolist())
            true_values.extend(labels.tolist())

    report = classification_report(true_values, pred_values, labels=range(len(label_names)), target_names=label_names,
                                   digits=4, zero_division=0)

    logger.info('The confusion matrix for this {} data: \n {}'.format(type, report))

    return report
