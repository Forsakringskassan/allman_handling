import json
import logging.config
import os
import shutil

import torch
import torch.nn as nn
from sherlock_common.model import Model
from sherlock_common.model_functions import load_pretrained_model, save_trained_model
from torch.utils import data

from training_runner.dataset_transformer import DatasetTransformer, data_processing
from training_runner.model_functions import train, evaluation, final_evaluation

BASE_MODEL = "bert-base-cased"
VOCAB_FILE_NAME = 'vocab.txt'
CONFIG_FILE_NAME = 'config.json'
DATASET_TRAINING = 'training'
DATASET_TEST = 'test'
SOFTMAX = "softmax"
SIGMOID = "sigmoid"

MSG_OUTPUT_ACTIVATION_NO_SUPPORT = 'Current version only support softmax and sigmoid.'
MSG_SIGMOID_SCOPE = 'The value of the sigmoid threshold should be between 0 and 1.'
MSG_BATCH_SIZE_ERROR = 'Batch size should be bigger than 0.'
MSG_EPOCHS_ERROR = 'Epochs should be bigger than 0.'
MSG_POSITIVE_TARGET_ERROR = 'The positive target should be one of input data folder name.'
MSG_LABEL_MISMATCH = "Train and test data labels should be same. "

logger = logging.getLogger(__name__)


def training(batch_size, epochs, training_data_path, test_data_path, output_path,
             bert_model_path, model_name, learning_rate, output_activation_type,
             binary_target, sigmoid_threshold, existing_model_path=None):
    use_cuda = torch.cuda.is_available()
    device = torch.device("cuda" if use_cuda else "cpu")
    kwargs = {'num_workers': 1, 'pin_memory': True} if use_cuda else {}

    clean_pkl(training_data_path)
    clean_pkl(test_data_path)

    training_dataset = DatasetTransformer(training_data_path, type=DATASET_TRAINING, pre_trained_model=bert_model_path,
                                          max_len=128, output_activation_type=output_activation_type)
    test_dataset = DatasetTransformer(test_data_path, type=DATASET_TEST, pre_trained_model=bert_model_path,
                                      max_len=128, output_activation_type=output_activation_type)

    validate_input(batch_size, epochs, training_dataset._labels, test_dataset._labels, binary_target,
                   output_activation_type, sigmoid_threshold)

    training_loader = data.DataLoader(dataset=training_dataset,
                                      batch_size=batch_size,
                                      shuffle=True,
                                      collate_fn=lambda x: data_processing(x),
                                      **kwargs)

    test_loader = data.DataLoader(dataset=test_dataset,
                                  batch_size=batch_size,
                                  shuffle=False,
                                  collate_fn=lambda x: data_processing(x),
                                  **kwargs)

    create_output_directory(output_path)

    if output_activation_type == SOFTMAX:
        loss_fct = nn.CrossEntropyLoss()
    elif output_activation_type == SIGMOID:
        loss_fct = nn.BCEWithLogitsLoss()

    if existing_model_path:
        model, best_valid_loss = get_model(existing_model_path, device)
    else:
        existing_model_path = bert_model_path
        model, best_valid_loss = create_model(output_path, existing_model_path, training_dataset._labels, binary_target,
                                              output_activation_type, device)

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    iteration = 0
    for epoch in range(1, epochs + 1):
        iteration = train(model, device, training_loader, loss_fct, optimizer, iteration, output_activation_type)
        test_loss = evaluation(model, device, test_loader, loss_fct, iteration, output_activation_type)
        if test_loss < best_valid_loss:
            best_valid_loss = test_loss
            save_trained_model(output_path, model, model_name, best_valid_loss, device)

    final_evaluation(model, device, test_loader, output_activation_type, test_dataset._labels, "test",
                     sigmoid_threshold)
    final_evaluation(model, device, training_loader, output_activation_type, training_dataset._labels, "training",
                     sigmoid_threshold)
    clean_pkl(training_data_path)
    clean_pkl(test_data_path)


def create_model(model_path, pre_trained_model, labels, binary_target, output_activation_type, device):
    model = Model(pre_trained_model, len(labels), type="base").to(device)
    config_file_path = os.path.join(pre_trained_model, CONFIG_FILE_NAME)
    save_config_path = os.path.join(model_path, CONFIG_FILE_NAME)
    update_config(config_file_path, save_config_path, labels, binary_target, output_activation_type)
    shutil.copy(os.path.join(pre_trained_model, VOCAB_FILE_NAME), model_path)
    best_valid_loss = float("inf")
    return model, best_valid_loss


def clean_pkl(data_path):
    pkl_data = os.path.join(data_path, DATASET_TRAINING + '.pkl')
    if os.path.exists(pkl_data):
        os.remove(pkl_data)


def validate_input(batch_size, epochs, train_labels, test_labels, binary_target, output_activation_type,
                   sigmoid_threshold):
    if batch_size < 1:
        logger.error(MSG_BATCH_SIZE_ERROR)
        raise ValueError(MSG_BATCH_SIZE_ERROR)

    if epochs < 1:
        logger.error(MSG_EPOCHS_ERROR)
        raise ValueError(MSG_EPOCHS_ERROR)

    if output_activation_type != SIGMOID and output_activation_type != SOFTMAX:
        logger.error(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)
        raise ValueError(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)

    if train_labels != test_labels:
        logger.error(MSG_LABEL_MISMATCH)
        raise ValueError(MSG_LABEL_MISMATCH)

    if len(train_labels) == 2 and output_activation_type == SOFTMAX and binary_target not in train_labels:
        logger.error(MSG_POSITIVE_TARGET_ERROR)
        raise ValueError(MSG_POSITIVE_TARGET_ERROR)

    if sigmoid_threshold < 0 or sigmoid_threshold > 1:
        logger.error(MSG_SIGMOID_SCOPE)
        raise ValueError(MSG_SIGMOID_SCOPE)


def update_config(config_file_path, save_config_path, labels, binary_target, output_activation_type):
    with open(config_file_path, encoding='utf-8') as file:
        config = json.load(file)
    if len(binary_target) == 0:
        config['labels'] = {'values': labels}
    else:
        config['labels'] = {'values': labels,
                            'positive': {'value': binary_target, 'index': labels.index(binary_target)}}
    config['output_activation_type'] = output_activation_type
    config['num_label'] = len(labels)
    with open(save_config_path, 'w') as file:
        json.dump(config, file)


def get_model(model_path, device):
    model, best_valid_loss, _ = load_pretrained_model(model_path)
    model.to(device)
    return model, best_valid_loss


def create_output_directory(path):
    if not os.path.isdir(path):
        os.makedirs(path)
