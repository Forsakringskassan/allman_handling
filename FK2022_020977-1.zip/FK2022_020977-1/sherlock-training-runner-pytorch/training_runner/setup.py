from setuptools import setup, find_packages

setup(name='sherlock_training_runner_pytorch',
      version='0.0.7',
      packages=find_packages(),
      url='',
      license='',
      author='LO KOG',
      author_email='',
      description='Model training runner with pytorch'
      )
