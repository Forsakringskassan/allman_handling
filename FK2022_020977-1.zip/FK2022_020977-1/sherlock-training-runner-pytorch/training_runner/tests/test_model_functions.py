import os

import pytest
import torch.nn as nn
from sherlock_common.model import Model
from torch.utils import data

from training_runner.dataset_transformer import data_processing, DatasetTransformer
from training_runner.model_functions import calculate_loss, final_evaluation


@pytest.mark.parametrize("data_path, output_activation_type", [
    (pytest.TRAINING_DATA_PATH, 'softmax'),
    (pytest.MULTI_TRAINING_DATA_PATH, 'softmax'),
    (pytest.MULTI_TRAINING_DATA_PATH, 'sigmoid')])
def test_calculate_loss(data_path, output_activation_type):
    training_dataset = DatasetTransformer(data_path=data_path,
                                          pre_trained_model=pytest.DEFAULT_MODEL_PATH,
                                          max_len=128,
                                          type='training',
                                          output_activation_type=output_activation_type)
    training_loader = data.DataLoader(dataset=training_dataset,
                                      batch_size=pytest.BATCH_SIZE,
                                      shuffle=True,
                                      collate_fn=lambda x: data_processing(x))

    num_label = len(training_dataset._labels)
    model = Model(model_path=pytest.DEFAULT_MODEL_PATH, num_label=num_label)
    if output_activation_type == "softmax":
        loss_fct = nn.CrossEntropyLoss()
    elif output_activation_type == "sigmoid":
        loss_fct = nn.BCEWithLogitsLoss()
    training_data = next(iter(training_loader))
    device = pytest.DEVICE
    loss, text_len = calculate_loss(training_data, device, model, loss_fct,
                                    output_activation_type=output_activation_type)
    assert text_len == pytest.TEXT_LEN

    training_file_path = os.path.join(data_path, 'training.pkl')
    os.remove(training_file_path)


@pytest.mark.parametrize("data_path, output_activation_type, sigmoid_threshold", [
    (pytest.TRAINING_DATA_PATH, 'softmax', 0.5),
    (pytest.MULTI_TRAINING_DATA_PATH, 'softmax', 0.5),
    (pytest.MULTI_TRAINING_DATA_PATH, 'sigmoid', 0.6)])
def test_final_evaluation(data_path, output_activation_type, sigmoid_threshold):
    dataset = DatasetTransformer(data_path=data_path,
                                 pre_trained_model=pytest.DEFAULT_MODEL_PATH,
                                 max_len=128,
                                 type='training',
                                 output_activation_type=output_activation_type)
    data_loader = data.DataLoader(dataset=dataset,
                                  batch_size=pytest.BATCH_SIZE,
                                  shuffle=True,
                                  collate_fn=lambda x: data_processing(x))

    num_label = len(dataset._labels)
    model = Model(model_path=pytest.DEFAULT_MODEL_PATH, num_label=num_label)

    report = final_evaluation(model, pytest.DEVICE, data_loader, output_activation_type, dataset._labels, "test",
                              sigmoid_threshold)

    assert len(report) > 0
