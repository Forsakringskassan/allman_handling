import os

import pytest


def pytest_configure():
    pytest.DEFAULT_MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'model',
                                             'bert-base-cased')
    pytest.MODEL_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'model',
                                     'b130')
    pytest.TRAINING_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                             'resources', 'data', 'dataset', 'b117', 'training')
    pytest.MULTI_TRAINING_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                   'resources', 'data', 'dataset', 'multi', 'training')
    pytest.NOT_ENOUGH_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          'resources', 'data', 'dataset', 'd230', 'test')
    pytest.TEST_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         'resources', 'data', 'dataset', 'b117', 'test')
    pytest.FAKE_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'fakedata')
    pytest.BATCH_SIZE = 5
    pytest.DEVICE = 'cpu'
    pytest.MAX_LEN = 128  # default one in the Transform class
    pytest.NUM_LABEL = 2
    pytest.EPOCHS = 1
    pytest.OUTPUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'model')
    pytest.OUTPUT_MODEL_NAME = 'best_model'
    pytest.LEARNING_RATE = 0.001
    pytest.SIGMOID_THRESHOLD = 0.5
    pytest.BINARY_TARGET = "positive"
    pytest.OUTPUT_ACTIVATION_TYPE = "softmax"

    pytest.PICKEL_TEST_INPUT_RESULT_0 = [2, 1339, 3532, 82, 108, 817, 59, 3580, 3, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0]

    pytest.PICKEL_TEST_MASK_RESULT_0 = [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                        0, 0, 0, 0, 0, 0, 0, 0, 0]

    pytest.PICKEL_TEST_LABEL_RESULT_ALL = ['negative', 'negative', 'negative', 'negative', 'negative', 'negative',
                                           'positive', 'positive', 'positive']

    pytest.PICKEL_TEST_NUM_DATA = 9

    pytest.PICKEL_TRAIN_INPUT_RESULT_0 = [2, 1662, 1527, 6755, 49795, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                          0, 0, 0]

    pytest.PICKEL_TRAIN_MASK_RESULT_0 = [1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    pytest.PICKEL_TRAIN_LABEL_RESULT_ALL = ['negative', 'negative', 'negative', 'negative', 'negative', 'negative',
                                            'positive', 'positive', 'positive']

    pytest.TRAIN_LABEL_OUTPUT_SIGMOID = [[1, 0], [1, 0], [1, 0], [1, 0], [1, 0], [1, 0], [0, 1], [0, 1], [0, 1]]
    pytest.TRAIN_LABEL_OUTPUT_SOFTMAX = [0, 0, 0, 0, 0, 0, 1, 1, 1]
    pytest.TEST_LABEL_OUTPUT_SOFTMAX = [0, 0, 0, 0, 0, 0, 1, 1, 1]

    pytest.PICKEL_TRAIN_NUM_DATA = 15
    pytest.TEXT_LEN = 5
