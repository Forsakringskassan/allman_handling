import os
import pickle

import pytest
import torch
from torch.utils import data

from training_runner.dataset_transformer import MSG_DATASET_DIR_MISSING, MSG_DATASET_SUBDIR_MISSING
from training_runner.dataset_transformer import data_processing, DatasetTransformer


@pytest.mark.parametrize("data_path, pre_trained_model, type, exception_message", [
    (pytest.FAKE_DATA_PATH, pytest.DEFAULT_MODEL_PATH, 'training', MSG_DATASET_DIR_MISSING),
    (pytest.NOT_ENOUGH_FILE, pytest.DEFAULT_MODEL_PATH, 'training', MSG_DATASET_SUBDIR_MISSING)
])
def test_value_error_raised(data_path, pre_trained_model, type, exception_message):
    with pytest.raises(ValueError) as e:
        DatasetTransformer(data_path=data_path,
                            pre_trained_model=pre_trained_model,
                            max_len=128,
                            output_activation_type='softmax',
                            type=type)
    assert str(e.value) == exception_message

@pytest.mark.parametrize("label_result, type, output_activation_type, output_labels", [
    (pytest.PICKEL_TRAIN_LABEL_RESULT_ALL, 'training','sigmoid', pytest.TRAIN_LABEL_OUTPUT_SIGMOID),
    (pytest.PICKEL_TRAIN_LABEL_RESULT_ALL, 'training', 'softmax', pytest.TRAIN_LABEL_OUTPUT_SOFTMAX),
    (pytest.PICKEL_TEST_LABEL_RESULT_ALL, 'test', 'softmax', pytest.TEST_LABEL_OUTPUT_SOFTMAX)])
def test_dataset_transformer_class(output_activation_type, type, label_result, output_labels):
    """ test the input to initial the DatasetTransformer class"""
    dataset = DatasetTransformer(data_path=pytest.TRAINING_DATA_PATH,
                                          pre_trained_model=pytest.DEFAULT_MODEL_PATH,
                                          max_len=128,
                                          output_activation_type=output_activation_type,
                                          type=type)

    file_path = os.path.join(pytest.TRAINING_DATA_PATH, type + '.pkl')
    assert len(dataset._input_ids) == len(dataset._masks)
    assert len(dataset._input_ids) == len(dataset._output_labels)
    assert len(dataset._input_ids) == 9

    assert dataset._output_labels == output_labels

    assert os.path.exists(file_path)

    with open(file_path, 'rb') as handle:
        result_dic = pickle.load(handle)

    assert result_dic['input_ids'][0] == pytest.PICKEL_TRAIN_INPUT_RESULT_0
    assert result_dic['masks'][0] == pytest.PICKEL_TRAIN_MASK_RESULT_0
    assert result_dic['labels'] == label_result

    os.remove(file_path)

@pytest.mark.parametrize("data_path, output_activation_type", [
    (pytest.TRAINING_DATA_PATH, 'softmax'),
    (pytest.MULTI_TRAINING_DATA_PATH, 'softmax'),
    (pytest.MULTI_TRAINING_DATA_PATH, 'sigmoid')])
def test_data_processing(data_path, output_activation_type):
    output_activation_type = "softmax"
    """test the data processing function called from DataLoader """
    training_dataset = DatasetTransformer(data_path=data_path,
                                          pre_trained_model=pytest.DEFAULT_MODEL_PATH,
                                          max_len=pytest.MAX_LEN,
                                          output_activation_type = output_activation_type,
                                          type='training')
    train_loader = data.DataLoader(dataset=training_dataset,
                                   batch_size=pytest.BATCH_SIZE,
                                   shuffle=True,
                                   collate_fn=lambda x: data_processing(x))
    first_item = next(iter(train_loader))
    assert len(first_item) == 3
    assert isinstance(first_item[0], torch.Tensor)
    assert isinstance(first_item[1], torch.Tensor)
    assert isinstance(first_item[2], torch.LongTensor)
    assert first_item[0].shape == first_item[1].shape
    assert first_item[0].shape[0] == pytest.BATCH_SIZE
    assert first_item[1].shape[0] == pytest.BATCH_SIZE
    assert first_item[2].shape[0] == pytest.BATCH_SIZE

    training_file_path = os.path.join(data_path, 'training.pkl')
    os.remove(training_file_path)