import json
import os
import shutil

import pytest

from training_runner.model_train import training, update_config, create_output_directory, CONFIG_FILE_NAME


@pytest.mark.parametrize("labels, binary_target, output_activation_type, result", [
    (['positive', 'negative'], 'positive', 'softmax', {'value': 'positive', 'index': 0}),
    (['positive', 'negative'], '', 'sigmoid', None),
    (['b112', 'b113', 'b114'], '', 'softmax', None)])
def test_update_config(labels, binary_target, output_activation_type, result):
    config_file_path = os.path.join(pytest.DEFAULT_MODEL_PATH, CONFIG_FILE_NAME)
    save_file_path = os.path.join(pytest.MODEL_PATH, CONFIG_FILE_NAME)
    create_output_directory(pytest.MODEL_PATH)

    update_config(config_file_path, save_file_path, labels, binary_target, output_activation_type)
    assert os.path.exists(save_file_path)

    with open(save_file_path, 'rb') as handle:
        result_dic = json.load(handle)
    if result is not None:
        assert result_dic['labels']['positive'] == result
    else:
        assert 'positive' not in result_dic['labels'].keys()
    assert result_dic['num_label'] == len(labels)
    assert result_dic['output_activation_type'] == output_activation_type
    assert result_dic['labels']['values'] == labels

    shutil.rmtree(pytest.MODEL_PATH)


def test_validate_input():
    with pytest.raises(ValueError):
        training(batch_size=pytest.BATCH_SIZE,
                 epochs=pytest.EPOCHS,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type="not_in_softmax_or_sigmoid",
                 binary_target=pytest.BINARY_TARGET,
                 sigmoid_threshold=pytest.SIGMOID_THRESHOLD)

    with pytest.raises(ValueError):
        training(batch_size=pytest.BATCH_SIZE,
                 epochs=pytest.EPOCHS,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type=pytest.OUTPUT_ACTIVATION_TYPE,
                 binary_target="not_positive",
                 sigmoid_threshold=pytest.SIGMOID_THRESHOLD)

    with pytest.raises(ValueError):
        training(batch_size=pytest.BATCH_SIZE,
                 epochs=pytest.EPOCHS,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type=pytest.OUTPUT_ACTIVATION_TYPE,
                 binary_target=pytest.BINARY_TARGET,
                 sigmoid_threshold=1.2)

    with pytest.raises(ValueError):
        training(batch_size=pytest.BATCH_SIZE,
                 epochs=pytest.EPOCHS,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type=pytest.OUTPUT_ACTIVATION_TYPE,
                 binary_target=pytest.BINARY_TARGET,
                 sigmoid_threshold=-0.1)

    with pytest.raises(ValueError):
        training(batch_size=0,
                 epochs=pytest.EPOCHS,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type=pytest.OUTPUT_ACTIVATION_TYPE,
                 binary_target=pytest.BINARY_TARGET,
                 sigmoid_threshold=pytest.SIGMOID_THRESHOLD)

    with pytest.raises(ValueError):
        training(batch_size=pytest.BATCH_SIZE,
                 epochs=0,
                 test_data_path=pytest.TEST_DATA_PATH,
                 training_data_path=pytest.TRAINING_DATA_PATH,
                 output_path=pytest.OUTPUT_PATH,
                 bert_model_path=pytest.DEFAULT_MODEL_PATH,
                 existing_model_path=pytest.OUTPUT_PATH,
                 model_name=pytest.OUTPUT_MODEL_NAME,
                 learning_rate=pytest.LEARNING_RATE,
                 output_activation_type=pytest.OUTPUT_ACTIVATION_TYPE,
                 binary_target=pytest.BINARY_TARGET,
                 sigmoid_threshold=pytest.SIGMOID_THRESHOLD)
