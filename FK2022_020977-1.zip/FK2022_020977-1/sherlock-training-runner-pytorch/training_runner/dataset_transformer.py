import logging
import os
import pickle
import re

import pandas as pd
import torch
from sherlock_common.text_transform import TextTransform
from torch.utils.data import Dataset

MSG_DATASET_DIR_MISSING = 'Dataset directory does not exist.'
MSG_DATASET_SUBDIR_MISSING = 'Sub directory inside Dataset should be more than 2.'
MSG_VOC_FILE_MISSING = "Vocabulary file for text transformer does not exist."
MSG_READ_DATA_SOURCE_ERROR = "An error occurred with the file: {}."
MSG_OUTPUT_ACTIVATION_NO_SUPPORT = "We currently only supoort sigmoid and softmax activation type."
MSG_DATASET_CORRUPT = "The original input data files are corrupted."
TRAINING_PROPERTY = "training"

logger = logging.getLogger(__name__)


def data_processing(data):
    texts = []
    attention_masks = []
    labels = []
    for (input_id, mask, label) in data:
        texts.append(input_id)
        attention_masks.append(mask)
        labels.append(label)
    return torch.tensor(texts), torch.tensor(attention_masks), torch.LongTensor(labels)


class DatasetTransformer(Dataset):
    """
    Create a Dataset for LJSpeech-1.1. Each item is a tuple of the form:
    waveform, log mel spectrogram, sample_rate, transcript, normalized_transcript
    """
    _input_ids = []
    _masks = []
    _output_labels = []
    _labels = []

    def __init__(self, data_path, output_activation_type, pre_trained_model=None, max_len=128, type=TRAINING_PROPERTY):
        self.output_activation_type = output_activation_type
        self._get_input(data_path, pre_trained_model, max_len, type, output_activation_type)

    def __getitem__(self, n):
        return self._input_ids[n], self._masks[n], self._output_labels[n]

    def __len__(self):
        return len(self._input_ids)

    def _validate_input(self, data_folder):
        if not os.path.exists(data_folder):
            logger.error(MSG_DATASET_DIR_MISSING)
            raise ValueError(MSG_DATASET_DIR_MISSING)

        labels = [x[0] for x in os.walk(data_folder)]
        if len(labels) < 3:
            logger.error(MSG_DATASET_SUBDIR_MISSING)
            raise ValueError(MSG_DATASET_SUBDIR_MISSING)

    def _get_input(self, data_folder, pre_trained_model, max_len, type, output_activation_type):

        self._validate_input(data_folder)

        self._labels = self._get_label(data_folder)
        pickle_file = os.path.join(data_folder, type + '.pkl')

        transformer = TextTransform(pre_trained_model, max_len)

        if not os.path.isfile(pickle_file):
            dict = self._get_dataframe(data_folder, transformer)
            with open(pickle_file, "wb") as output_file:
                pickle.dump(dict, output_file)
        else:
            with open(pickle_file, "rb") as input_file:
                dict = pickle.load(input_file)

        self._input_ids = dict['input_ids']
        self._masks = dict['masks']
        labels_str = dict['labels']
        if self.output_activation_type == 'softmax':
            self._output_labels = [self._labels.index(i) for i in labels_str]
        elif self.output_activation_type == 'sigmoid':
            self._output_labels = [self._label_one_hot(i) for i in labels_str]
        else:
            logger.error(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)
            raise ValueError(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)

    def _get_label(self, folder):
        labels = [x[0] for x in os.walk(folder)]
        labels = [os.path.basename(i) for i in labels[1:]]
        labels = sorted(labels)
        return labels

    def _get_dataframe(self, folder, transformer):
        texts = []
        input_ids = []
        masks = []
        labels = []
        for label in self._labels:
            label_folder = os.path.join(folder, label)
            for dir, subdir, files in os.walk(label_folder):
                for file in sorted(files):
                    try:
                        f = open(os.path.join(dir, file), encoding='utf-8', mode='r')
                        text = f.read().split('\n')[0]
                        input_id, mask = transformer.text_to_int(text)
                        texts.append(text)
                        input_ids.append(input_id)
                        masks.append(mask)
                        labels.append(label)
                    except:
                        logger.error(MSG_DATASET_CORRUPT)
                        raise ValueError(MSG_DATASET_CORRUPT)

        data_tuples = list(zip(texts, input_ids, masks, labels))

        df = pd.DataFrame(data_tuples, columns=['sentence_texts', 'input_ids', 'masks', 'labels'])

        if self.output_activation_type == "sigmoid":
            df = df.drop_duplicates(subset=['sentence_texts', 'labels'])
            df['labels'] = df.groupby(['sentence_texts'])['labels'].transform(lambda x: ' '.join(x))
            df = df.drop_duplicates(subset=['sentence_texts', 'labels']).reset_index().drop(columns=['index'])

        return df.to_dict('list')

    def _label_one_hot(self, label):
        label = label.split(' ')
        output_labels = []
        for i in self._labels:
            if i in label:
                output_labels.append(1)
            else:
                output_labels.append(0)
        return output_labels
