# Sherlock-training-runner-pytorch

## Prerequisites

The things you need to install and how to install them

  * Python version 3.9.5

Installing for development

NOTE:
The develop pipeline requires the python agent to have at least 4 gb memory.

### Install python dependencies 
```
pip3 install -i <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
    --extra-index-url <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
    --trusted-host <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > -r requirements/dev-qa.txt
```

### Requirements

Sherlock-training-runner-pytorch needs a BERT-model and at least one pre trained model in order to run a prediction on some text.

The following folder structure is needed:

```sh
/resources
├── model
│   ├── bert-base-cased
│   │   ├── config.json
│   │   ├── vocab.txt
│   │   ├── pytorch_model.bin
├── data
│   ├── b130
│   │   ├── training
│   │   │   ├── positive
│   │   │   ├── negative
│   │   ├── test
│   │   │   ├── positive
│   │   │   ├── negative
```


## Running application locally
Run locally (requires that data directory is populated with a bert model and data)
```
python -m training_runner --testData=data/dataset/b130/test --trainingData=data/dataset/b130/training --output data/model/b130-01 --bertModel=data/model/bert-base-cased --seed=3456 --outputActivationtype=softmax --binaryTarget=positive
```
Commands:
```
usage: __main__.py [-h] --trainingData TRAINING_DATA_PATH --testData TEST_DATA_PATH --output OUTPUT_PATH --bertModel BERT_MODEL_PATH [--classifierModel EXISTING_MODEL_PATH] [--batchSize BATCH_SIZE] [--maxEpochs EPOCHS]
                   [--modelName MODEL_NAME] [--seed SEED]

Create a classifier using BERT and data provided.

required named arguments:
  --trainingData TRAINING_DATA_PATH
                        Training data path. Example: /data/dataset/d220/training
  --testData TEST_DATA_PATH
                        Test data path. Example: /data/dataset/d220/test
  --output OUTPUT_PATH  The output path, example: /data/model/d220-01
  --bertModel BERT_MODEL_PATH
                        bert model path. Example: /data/model/bert-base-cased

optional arguments:
  -h, --help            show this help message and exit
  --classifierModel EXISTING_MODEL_PATH
                        Existing classifier model path to continue training. Example: /data/model/d220/
  --batchSize BATCH_SIZE
                        Set batch size, default: 16
  --maxEpochs EPOCHS    Set epochs, default: 15
  --modelName MODEL_NAME
                        Model name, default: best_model
  --seed SEED           Desired manual seed which is used in torch for generating random numbers, default: 1234
  --learningRate LEARNING_RATE
                        Lerning rate in the training, default: 2e-5
  --outputActivationType OUTPUT_ACTIVATION_TYPE 
                        Output activation function type, default: softmax
  --binaryTarget BINARY_TARGET 
                        The binary classification target name, default:positive
```

## Run as a job in openshift
Copy and rename [openshift/train-b130.yaml](openshift/train-b130.yaml) to match the 
label you want to train. Update the yaml with the desired inputs and outputs.
``` 
oc create -f openshift/train-<LABEL>.yaml
```

### Non functional test report
see `<borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) >`