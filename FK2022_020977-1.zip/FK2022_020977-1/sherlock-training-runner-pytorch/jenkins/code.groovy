/**
 * Check if the image provided exists in nexus source.
 *
 * @param project name in nexus (not necessarily the same as openshift project)
 * @param nexusurl of external nexus to check
 * @param imagename image name to check
 * @param imageversion image version to check
 * @return if image exist or not.
 */
def checkIfImageAlreadyExistsInSourceNexus(project, nexusurl, imagename, imageversion) {
    def result=false
     stage ("Check if ${imagename}:${imageversion} is available in Nexus (${nexusurl}") {
            withCredentials([usernameColonPassword(credentialsId: "nexussrc", variable: 'nexussecret')]){
                try {
                    sh (returnStdout: false, script: "skopeo --insecure-policy inspect --tls-verify=false --creds=${nexussecret} docker://${nexusurl}/${project}/${imagename}:${imageversion}")
                    result=true
                } catch (error) {
                    // This is how you check if there is an image or not...
                }
            }
        }
    return result
}

/**
 * Check if the image provided exists in nexus destination.

 * @param project name in nexus (not necessarily the same as openshift project)
 * @param nexusurl of external nexus to check
 * @param imagename image name to check
 * @param imageversion image version to check
 * @return if image exist or not.
 */
def checkIfImageAlreadyExistsInDestinationNexus(project, nexusurl, imagename, imageversion ) {
    def result=false
    node () {
        stage ("Check if ${imagename}:${imageversion} is available in Nexus (${nexusurl}") {
            withCredentials([usernameColonPassword(credentialsId: "nexusdest", variable: 'nexussecret')]) {
                try {
                    sh (returnStdout: false, script: "skopeo --insecure-policy inspect --tls-verify=false --creds=${nexussecret} docker://${nexusurl}/${project}/${imagename}:${imageversion}")
                    result=true
                } catch (error) {
                    // This is how you check if there is an image or not.
                }
            }
        }
    }
    return result
}

/**
 * Copy image stream from external nexus registry to internal openshift registry.
 * @param project name in nexus (not necessarily the same as openshift project)
 * @param nexusurl of external nexus
 * @param imagename image name
 * @param imageversion image version
 */
def copyFromExternalNexus( project, nexusurl, imagename, imageversion){
    node(){
        stage ("Copy image ${imagename}:${imageversion} from external registry ${nexusurl}"){
            def token = readFile('/var/run/secrets/kubernetes.io/serviceaccount/token').trim()
            withCredentials([usernameColonPassword(credentialsId: "nexusdest", variable: 'nexussecret')]) {
                sh "skopeo --insecure-policy copy --src-tls-verify=false --dest-tls-verify=false --src-creds=${nexussecret} --dest-creds=jenkins:$token docker://${nexusurl}/${project}/${imagename}:${imageversion} docker://<borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) >/${openshift.project()}/${imagename}:${imageversion}"
            }
        }
    }
}

/**
 * Copy image stream from internal openshift registry to external nexus registry.
 * @param project name in nexus (not necessarily the same as openshift project)
 * @param nexusurl of external nexus
 * @param imagename image name
 * @param imageversion image version
 */
def copyToExternalNexus( project, nexusurl, imagename, imageversion){
    node () {
        stage ("Copy image to extern registry ${nexusurl}") {
            def token = readFile('/var/run/secrets/kubernetes.io/serviceaccount/token').trim()
            withCredentials([usernameColonPassword(credentialsId: "nexusdest", variable: 'nexussecret')]){
                sh "skopeo --insecure-policy copy --src-tls-verify=false --dest-tls-verify=false --src-creds=jenkins:$token --dest-creds=${nexussecret} docker://<borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) >/${openshift.project()}/${imagename}:${imageversion} docker://${nexusurl}/${project}/${imagename}:${imageversion}"
            }
        }
    }
}

/**
 *
 * @param project name in nexus (not necessarily the same as openshift project)
 * @param sourceNexusUrl of source external nexus containing image stream
 * @param targetNexusUrl of target external nexus to copy image stream
 * @param imagename image name
 * @param imageversion image version
 */
def copyImageBetweenExternalNexus( project, sourceNexusUrl, targetNexusUrl, imagename, imageversion ){
    node () {
        stage( "Copy image ${imagename}:${imageversion} from external registry ${sourceNexusUrl} to external repository ${targetNexusUrl}" ) {
            withCredentials( [usernameColonPassword( credentialsId: "nexussrc", variable: 'nexussecretSrc' ),
                               usernameColonPassword( credentialsId: "nexusdest", variable: 'nexussecretTarget' )] ) {
                sh "skopeo --insecure-policy copy --src-tls-verify=false --dest-tls-verify=false --src-creds=${nexussecretSrc} --dest-creds=${nexussecretTarget} docker://${sourceNexusUrl}/${project}/${imagename}:${imageversion} docker://${targetNexusUrl}/${project}/${imagename}:${imageversion}"
            }
        }
    }
}

/**
 * Tag the specified openshift image as latest in the internal openshift registry.
 *
 * @param imagename image name
 * @param imageversion image version
 */
def tagImageAsLatest( imagename, imageversion ){
    stage("Tag image ${imagename}:${imageversion} as latest") {
        openshift.tag("${imagename}:${imageversion}", "${imagename}:latest")
    }
}

/**
 * Tag the latest openshift image with this name with the provided version in the internal openshift registry
 *
 * @param imagename image name
 * @param imageversion image version to tag
 * @return
 */
def tagLatestAsVersion( imagename, imageversion ){
    stage("Tag image latest as ${imagename}:${imageversion}") {
        openshift.tag("${imagename}:latest", "${imagename}:${imageversion}")
    }
}

/**
 * Compare git branch names - if they match then it's a release branch.
 *
 * @param branch_name current GIT branch.
 * @param release_branch_name name of release branch
 * @return if this is a match for the release branch or not.
 */
def is_release_branch_fn(branch_name, release_branch_name){
    return (branch_name =~ "^${release_branch_name}") ? true : false
}

/**
 * Run the perfReport plugin on the provided file.
 * If the file does not exist, continue.
 *
 * @param file results file from running tests
 */
def doPerfReport( String file ){
    try{
        perfReport file
    }
    catch( error ){
        echo "Failed to generate report: " + error
    }
}

/**
 * Create a report that checks vulnerabilities in the dependencies.
 */
def create_nexus_iq_report( project, NexusIQUrl, cliJar, appID, reqFile ){
    stage( "Create dependency report in Nexus IQ" ) {
        withCredentials( [usernameColonPassword( credentialsId: "nexusiq ", variable: 'nexusiqsecret' )] ) {
            sh "java -jar ${cliJar} -i ${appID} -s ${NexusIQUrl} -a ${nexusiqsecret} ${reqFile}"
        }
    }
}


//Ensure functions are available after loading by returning "this"
return this
