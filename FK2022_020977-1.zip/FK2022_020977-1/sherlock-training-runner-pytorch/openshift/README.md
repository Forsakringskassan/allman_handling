# Openshift
NOTE: 
__All__ of the commands expects a user to be navigated in the root directory

```commandline
git update-index --chmod=+x gradlew
```

#### DEV
```commandline
oc process jenkins-pipeline --param-file=openshift/common.properties --param-file=openshift/build-DEV.properties -o=yaml| oc apply -f -
```

#### QA
```commandline
oc process jenkins-pipeline --param-file=openshift/common.properties --param-file=openshift/build-QA.properties -o=yaml| oc apply -f -
```

#### PROD
```commandline
oc process jenkins-pipeline --param-file=openshift/common.properties --param-file=openshift/build-PROD.properties -o=yaml| oc apply -f -
```
