# Openshift

```commandline
git update-index --chmod=+x gradlew
```

NOTE: 

The following commands expects a user to be navigated in the root directory

#### DEV
```commandline
oc process jenkins-pipeline --param-file=build-DEV.properties -o=yaml| oc apply -f -
```

#### QA
```commandline
oc process jenkins-pipeline --param-file=build-QA.properties -o=yaml| oc apply -f -
```

#### PROD
```commandline
oc process jenkins-pipeline --param-file=build-PROD.properties -o=yaml| oc apply -f -
```
