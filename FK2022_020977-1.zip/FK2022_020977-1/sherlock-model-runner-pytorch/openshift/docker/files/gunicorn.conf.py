# Settings for Gunicorn server
import multiprocessing
import os

from prometheus_client import multiprocess

HOST_BIND_IP = os.getenv('HOST_BIND_IP', '0.0.0.0')
HOST_BIND_PORT = os.getenv('HOST_BIND_PORT', '9990')
GUNICORN_THREADS = int(os.getenv('GUNICORN_THREADS', '8'))

bind = HOST_BIND_IP + ":" + HOST_BIND_PORT
timeout = 60
workers = 1
threads = GUNICORN_THREADS
pythonpath = '/opt/app/model_runner'

preload = True

def child_exit(server, worker):
    multiprocess.mark_process_dead(worker.pid)