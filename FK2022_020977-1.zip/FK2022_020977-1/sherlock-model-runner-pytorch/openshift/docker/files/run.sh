#! /bin/bash

./venv/bin/gunicorn --config ./gunicorn.conf.py model_runner.app:app