/**
* Create an application if it does not already exist.
*
* @param imageName name of the image to create the application from.
* @param imageVersion version of the image to create the application from.
* @param dcName name of the deployment configuration to create.
* @param label app to be applied to the created application.
* @param zone to be applied to the created application.
*/
def createApp( String imageName, String imageVersion, String dcName, String label, String zone ){
    if( !openshift.selector( "dc", "${dcName}" ).exists() ) {
        openshift.raw( "new-app ${imageName}:${imageVersion} --name=${dcName} --labels app=${label},zone=${zone} --as-deployment-config" )
        def nodeSelectorPatch = readFile( "jenkins/nodeSelectorPatch.json" )
            .replaceAll('<ZONE>', "${zone}")
        openshift.raw( "patch dc ${dcName} -p '${nodeSelectorPatch}'" )
    }
}

/**
 * Configure the dc for the environment type provided.
 *
 * @param dcName of the dc to configure.
 * @param cName name of the c to set quota.
 * @param envType environment type to use when reading the deploy.properties.
 */
def configureApp( String dcName, String cName, String envType ){
    def deployProperties = readProperties file: "openshift/$envType/deploy.properties"
    deployProperties = groupProperties( deployProperties )
    pauseRollout( dcName )
    setQuota( dcName, cName, deployProperties["quota"] )
    setVolumes( dcName, cName, deployProperties["volume"] )
    setEnvironment( dcName, cName, deployProperties["env"] )
    setProbes( dcName, cName, deployProperties["probe"] )
    setMonitoring( dcName )
    resumeRollout( dcName )
}

/**
 * Group properties with similar prefixes together.
 * Removing the key prefix.
 *
 * @param properties all properties
 * @return map of prefixes to the grouped of properties with that prefix, now removed.
 */
def groupProperties( Map properties ){
    Map<String,Map<Object,Object>> result = new HashMap<>()

    for( Map.Entry<Object,Object> entry: properties.entrySet(  ) ){
        String key = entry.getKey(  )
        String[] split = key.split("\\." )
        String type = split[0]
        key = key.substring( type.length(  ) + 1 )
        Map<Object,Object> values = result.getOrDefault( type, new HashMap<>() )
        values.put( key, entry.getValue(  ) )
        result.put( type, values )
    }
    return result
}

/**
 * Pause the rollout of the dc.
 * To help group changes to the dc before rolling them out.
 *
 * @param dcName name of the dc to pause.
 */
def pauseRollout( String dcName ){
    openshift.raw( "rollout pause dc ${dcName}" )
}

/**
 * Set the quota of the dc main container with the values provided.
 *
 * Valid property keys:
 * - limit.cpu
 * - limit.memory
 *
 * @param dcName name of the dc to set quota.
 * @param cName name of the c to set quota.
 * @param quotaProperties values for quota.
 */
def setQuota( String dcName, String cName, Map quotaProperties ){
    setQuota( dcName, cName, quotaProperties['limit.cpu'], quotaProperties['limit.memory'],
                      quotaProperties['request.cpu'], quotaProperties['request.memory'] )
}

/**
 * Set the quota of the dc main container with the values provided.
 *
 * @param dcName name of the dc to set quota.
 * @param cName name of the c to set quota.
 * @param cpuLimit cpu limit to set.
 * @param memoryLimit memory limit to set.
 * @param cpuRequest cpu request to set.
 * @param memoryRequest memroy request to set.
 */
def setQuota( String dcName, String cName, String cpuLimit, String memoryLimit, String cpuRequest, String memoryRequest ){
   openshift.raw( "set resources dc ${dcName} -c ${cName} " +
                   "--requests=cpu=${cpuRequest},memory=${memoryRequest} " +
                   "--limits=cpu=${cpuLimit},memory=${memoryLimit}" )
}

/**
 * Set the quota of the dc main container with the values provided.
 *
 * @param dcName name of the dc to set quota.
 * @param cName name of the c to set quota.
 * @param envType which environment.
 */
def setQuota( String dcName, String cName, String envType ){
    def deployProperties = readProperties file: "openshift/$envType/deploy.properties"
    deployProperties = groupProperties( deployProperties )
    quotaProperties = deployProperties['quota']
    setQuota( dcName, cName, quotaProperties['limit.cpu'], quotaProperties['limit.memory'],
                      quotaProperties['request.cpu'], quotaProperties['request.memory'] )
}

/**
 * Set the quota of the dc main container to guarantee the limits provided.
 * I.e. Such that the request and limit values are set to the limit value,
 * resulting in a guaranteed quota.
 * This is useful prior to performing non functional tests etc.
 *
 * @param dcName name of the dc to set quota.
 * @param cName name of the c to set quota.
 * @param envType which environment.
 */
def setQuotaGuaranteed( String dcName, String cName, String envType ){
    def deployProperties = readProperties file: "openshift/$envType/deploy.properties"
    deployProperties = groupProperties( deployProperties )
    quotaProperties = deployProperties['quota']
    setQuota( dcName, cName, quotaProperties['limit.cpu'], quotaProperties['limit.memory'],
                      quotaProperties['limit.cpu'], quotaProperties['limit.memory'] )
}


/**
 * Set the volumes on the dc main container with the values provided.
 *
 * Keys should match a valid pvc name and values the mount point.
 * mypvc=/data
 *
 * @param dcName name of the dc to set volumes.
 * @param cName name of the c to set quota.
 * @param volumeProperties volumes to set.
 */
def setVolumes( String dcName, String cName, Map volumeProperties ){
    for( Map.Entry<String,Object> volume: volumeProperties.entrySet() ){
        setVolume( dcName, cName, volume.getKey(), volume.getValue() )
    }
}

/**
 * Set a volume on the dc main container.
 *
 * @param dcName name of the dc to set volume.
 * @param cName name of the c to set quota.
 * @param claim pvc name to mount.
 * @param mount location to mount the pvc.
 */
def setVolume( String dcName, String cName, String claim, String mount ){
    openshift.raw( "set volume dc/${dcName} --add --claim-name=${claim} --mount-path=${mount} --containers=${cName}")
}

/**
 * Set the environment variables for the dc main container.
 *
 * Key value pairs of environment variable names and values.
 *
 * @param dcName name of the dc to set environment variables.
 * @param cName name of the c to set quota.
 * @param envs variables to set.
 */
def setEnvironment( String dcName, String cName, Map envs ){
    for( Map.Entry<String,Object> env: envs.entrySet() ){
        setEnv( dcName, cName, env.getKey(), env.getValue() )
    }
}

/**
 * Set environment variable on dc main container.
 * @param dcName name of dc to set environment variable.
 * @param cName name of the c to set quota.
 * @param name of environment variable
 * @param value of environment variable.
 */
def setEnv( String dcName, String cName, String name, Object value ){
    openshift.raw( "set env dc/${dcName} ${name}=${value} --containers=${cName}")
}

/**
 * Set the readiness and liveness probes for the dc main container.
 * @param dcName name of the dc to set probes.
 * @param cName name of the c to set quota.
 * @param probeProperties probe properties to set.
 */
def setProbes( String dcName, String cName, Map probeProperties ){
    def probes = groupProperties( probeProperties )
    def readinessOptions = createCommandString( probes['readiness'] )
    def livenessOptions = createCommandString( probes['liveness'] )

    openshift.raw( "set probe dc/${dcName} --remove --readiness --liveness" )
    openshift.raw( "set probe dc/${dcName} --readiness ${readinessOptions} --containers=${cName}" )
    openshift.raw( "set probe dc/${dcName} --liveness ${livenessOptions} --containers=${cName}" )
}

/**
 * Create a command line string with a flag for each
 * key value pair provided.
 *
 * @param properties command line flags
 */
def createCommandString( Map properties ){
    StringBuilder flags = new StringBuilder()

    for( Map.Entry<String,Object> property: properties.entrySet() ){
        flags.append( " --" ).append( property.getKey() ).append( "=" ).append( property.getValue() )
    }

    return flags.toString()
}

/**
 * Setup monitoring for the dc.
 *
 * @param dcName name of the dc to setup monitoring for.
 */
def setMonitoring( String dcName ){
    def telegraf_sidecar_patch = readFile( "jenkins/telegraf/sidecar_patch.json" ).replaceAll( '<APP_NAME>',"${dcName}" )
    def telegraf_volume_patch = readFile( "jenkins/telegraf/volume_patch.json" )

    openshift.raw( "patch dc ${dcName} -p '${telegraf_volume_patch}'" )
    openshift.raw( "patch dc ${dcName} -p '${telegraf_sidecar_patch}'" )
    openshift.raw("set env --from=secret/telegraf-secret dc/${dcName} --containers='telegraf'")
}

/**
 * Resume the rollout of the dc.
 *
 * @param dcName name of the dc to resume rollout.
 */
def resumeRollout( String dcName ){
    openshift.raw( "rollout resume dc ${dcName}" )
}

/**
 * Wait until dc rollout is complete.
 *
 * Note - if the dc replica count is 0, this will return instantly.
 *
 * @param dcName name of the dc to wait upon.
 */
def waitUntilReady( String dcName ){
    openshift.raw( "rollout status dc ${dcName}" )
}

//Ensure functions are available after loading by returning "this"
return this