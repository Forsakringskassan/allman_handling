from flask_restful import Resource


class EntryPointRepresentation(Resource):
    @staticmethod
    def get():
        return {
            "_links": {
                "curies": [
                    {
                        "href": "/docs/{rel}",
                        "templated": True,
                        "name": "sherlock"
                    }
                ],
                "self": {
                    "href": "/"
                },
                "sherlock:predict": {
                    "href": "/prediction{?configId}",
                    "templated": True
                }
            }
        }