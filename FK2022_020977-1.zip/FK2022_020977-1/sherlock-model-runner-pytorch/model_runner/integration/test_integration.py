import pytest
import requests

from model_runner.app import ERROR_MSG_TEXT_EMPTY, ERROR_MSG_MODEL_NOT_EXISTS
from model_runner.representation import EntryPointRepresentation

TEST_MODEL_URL = "<borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) >"


def get_entrypoint_response(base_url):
    return requests.get(base_url + "/")


def get_prediction_url(base_url, config_id):
    json_response = get_entrypoint_response(base_url).json()
    predict_path = json_response["_links"]["sherlock:predict"]["href"]

    # TODO: hardcoded param will be replaced with a URI Template RFC6570 library
    param = "?configId={}".format(config_id)
    url = base_url + predict_path.replace("{?configId}", param)
    return url


def assert_json_response(config_id, text, response):
    assert response['labels']
    assert response['text'] == text
    assert response['meta']

    assert response['meta']['config'] == config_id
    assert response['meta']['version']

    results = response['labels']
    if config_id == 'all':
        label_names = [i['name'] for i in results]
        assert len(label_names) == len(set(label_names))
        for item in results:
            assert isinstance(item['probability'], float)
            assert config_id in item['source']
            assert item['type'] == "icf-koder"
    else:
        assert len(results) == 1
        assert response['labels'][0]['name'] == config_id
        assert isinstance(response['labels'][0]['probability'], float)
        assert config_id in response['labels'][0]['source']
        assert response['labels'][0]['type'] == "icf-koder"


def assert_model(base_url, config_id):
    # given:
    body = {"text": "Problem och svårigheter att skriva åäö, blandar ihop med a och o."}
    url = get_prediction_url(base_url, config_id)

    # when:
    response = requests.post(url, body)
    response_json = response.json()

    # then:
    assert response.status_code == 200
    assert_json_response(config_id, body["text"], response_json)


def test_get_entrypoint_returns_200():
    # given:
    expected = EntryPointRepresentation.get()

    # when:
    response = get_entrypoint_response(TEST_MODEL_URL)
    actual = response.json()

    # then:
    assert response.status_code == 200
    assert actual == expected


def test_missing_text_returns_400():
    # given:
    body = {"random": "value"}
    config_id = "does_not_exist"
    expected = {'message': ERROR_MSG_TEXT_EMPTY}
    url = get_prediction_url(TEST_MODEL_URL, config_id)

    # when:
    response = requests.post(url, body)
    actual = response.json()

    # then:
    assert response.status_code == 400
    assert actual == expected


def test_missing_model_returns_404():
    # given:
    body = {"text": "haha"}
    config_id = "does_not_exist"
    expected = {'message': ERROR_MSG_MODEL_NOT_EXISTS.format(config_id)}
    url = get_prediction_url(TEST_MODEL_URL, config_id)

    # when:
    response = requests.post(url, body)
    actual = response.json()

    # then:
    assert response.status_code == 404
    assert actual == expected


@pytest.mark.parametrize("base_url, config_id", [
                        (TEST_MODEL_URL, "d298"),
                        ("<borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) >", "b164")])
def test_model_successfully(base_url, config_id):
    assert_model(base_url, config_id)
