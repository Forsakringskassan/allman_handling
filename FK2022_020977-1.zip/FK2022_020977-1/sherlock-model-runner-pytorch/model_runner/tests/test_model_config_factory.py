from pathlib import Path

import pytest

from model_runner.model_facade import ModelFacadeFactory, ModelNotFoundException

TEST_RESOURCES_DIR = Path(__file__).resolve().parent / 'resources'
base_path = (TEST_RESOURCES_DIR / 'model').__str__()

# given: initialised model facade from directory
models = {
    'b134': {'source': 'se.fk.kog.sherlock.bert.icf:b134:1.0.0',
             'path': base_path + '/se.fk.kog.sherlock.bert.icf/b134/1.0.0'},
    'd220': {'source': 'se.fk.kog.sherlock.bert.icf:d220:1.0.0-SNAPSHOT',
             'path': base_path + '/se.fk.kog.sherlock.bert.icf/d220/1.0.0-SNAPSHOT'},
    '0': {'source': 'se.fk.kog.sherlock.bert.icf.grad:0:1.0.0',
          'path': base_path + '/se.fk.kog.sherlock.bert.icf.grad/0/1.0.0'},
    'multi-grad': {'source': 'se.fk.kog.sherlock.bert.icf.grad:multi-grad:2.0.0',
                   'path': base_path + '/se.fk.kog.sherlock.bert.icf.grad/multi-grad/2.0.0'},
}
instance = ModelFacadeFactory(base_path)




def test_get_models():
    # when: model are retrieves
    actual = instance.get_models()

    # then: maps matches
    assert actual == models


@pytest.mark.parametrize("config_id, expected", [
    pytest.param("b134", "se.fk.kog.sherlock.bert.icf:b134:1.0.0"),
    pytest.param("d220", "se.fk.kog.sherlock.bert.icf:d220:1.0.0-SNAPSHOT"),
    pytest.param("0", "se.fk.kog.sherlock.bert.icf.grad:0:1.0.0"),
    pytest.param("multi-grad", "se.fk.kog.sherlock.bert.icf.grad:multi-grad:2.0.0"),
])
def test_get_model_source(config_id, expected):
    # when: the source for the model is retrieved by config_id
    actual = instance.get_model_source(config_id)

    # then:
    assert actual == expected


def test_get_model_source_invalid_raises_error():
    # expect: the source for the model not present raises error
    with pytest.raises(KeyError):
        instance.get_model_source("invalid")


@pytest.mark.parametrize("config_id, expected", [
    pytest.param("b134", base_path + "/se.fk.kog.sherlock.bert.icf/b134/1.0.0"),
    pytest.param("d220", base_path + "/se.fk.kog.sherlock.bert.icf/d220/1.0.0-SNAPSHOT"),
    pytest.param("0", base_path + "/se.fk.kog.sherlock.bert.icf.grad/0/1.0.0"),
    pytest.param("multi-grad", base_path + "/se.fk.kog.sherlock.bert.icf.grad/multi-grad/2.0.0"),
])
def test_get_model_path(config_id, expected):
    # when: the path for the model is retrieved by config_id
    actual = instance.get_model_path(config_id)

    # then:
    assert actual == expected


def test_get_model_path_invalid_raises_error():
    # expect: the path for the model not present raises error
    with pytest.raises(KeyError):
        instance.get_model_path("invalid")


def test_initialise_factory():
    # given:
    path = "/test/path"
    device = "gpu"
    max_len = 12

    # when:
    instance = ModelFacadeFactory(path, device, max_len)

    # then:
    assert instance._models_path == path
    assert instance._device == device
    assert instance._max_len == max_len


def test_get_model_invalid():
    # expect: invalid model raises ModelNotFoundException
    with pytest.raises(ModelNotFoundException):
        instance.get_model("random")
