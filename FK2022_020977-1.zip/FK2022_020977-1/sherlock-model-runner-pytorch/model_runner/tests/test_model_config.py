import json
from pathlib import Path

import pytest

from model_runner.model_facade import ModelConfig

TEST_RESOURCES_DIR = Path(__file__).resolve().parent / 'resources'


@pytest.mark.parametrize("file, expected", [
    pytest.param(TEST_RESOURCES_DIR / "multi-grad/config.json", "icf-grad"),
    pytest.param(TEST_RESOURCES_DIR / "0/config.json", "icf-grad"),
    pytest.param(TEST_RESOURCES_DIR / "d220/config.json", "icf-koder"),
],)
def test_default_label_group(file, expected):
    # given: a config loaded from file.
    instance = ModelConfig(read_json(file))

    # when: label type is accessed.
    actual = instance.get_label_type()

    # then: the expected value is returned.
    assert actual == expected


@pytest.mark.parametrize("file, expected", [
    pytest.param(TEST_RESOURCES_DIR / "multi-grad/config.json", ["0", "1", "2", "3", "4", "8", "9"]),
    pytest.param(TEST_RESOURCES_DIR / "0/config.json", ["negative", "positive"]),
    pytest.param(TEST_RESOURCES_DIR / "d220/config.json", ["negative", "positive"]),
],)
def test_get_label_values(file, expected):
    # given: a config loaded from file.
    instance = ModelConfig(read_json(file))

    # when: label values are accessed.
    actual = instance.get_label_values()

    # then: the expected value is returned.
    assert actual == expected


@pytest.mark.parametrize("file, expected", [
    pytest.param(TEST_RESOURCES_DIR / "multi-grad/config.json", False),
    pytest.param(TEST_RESOURCES_DIR / "0/config.json", True),
    pytest.param(TEST_RESOURCES_DIR / "d220/config.json", True),
],)
def test_is_binary_classifier(file, expected):
    # given: a config loaded from file.
    instance = ModelConfig(read_json(file))

    # when: binary classifier is accessed.
    actual = instance.is_binary_classifier()

    # then: the expected value is returned.
    assert actual == expected


@pytest.mark.parametrize("file, expected", [
    pytest.param(TEST_RESOURCES_DIR / "0/config.json", 1),
    pytest.param(TEST_RESOURCES_DIR / "d220/config.json", 1),
],)
def test_get_positive_index(file, expected):
    # given: a config loaded from file.
    instance = ModelConfig(read_json(file))

    # when: positive index is accessed.
    actual = instance.get_positive_index()

    # then: the expected value is returned.
    assert actual == expected


def read_json(file_path):
    with open(file_path) as json_file:
        return json.load(json_file)

