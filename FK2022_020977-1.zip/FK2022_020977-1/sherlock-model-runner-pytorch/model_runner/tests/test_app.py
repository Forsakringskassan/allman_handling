from unittest import TestCase
from unittest import mock

from flask import json

from model_runner.app import ERROR_MSG_MODEL_NOT_EXISTS, ERROR_MSG_TEXT_EMPTY
from model_runner.app import app
from model_runner.model_facade import ModelNotFoundException, ModelFacadeFactory, ModelConfig
from model_runner.representation import EntryPointRepresentation

jsonData = {'text': 'some text that a prediction should be performed upon ÅÖÄäöå'}
configId = 'b117'
predict = [0]
probability_single = [[0.9114453196525574, 0.08855472505092621]]
config_single = {"labels": {"values": ["negative", "positive"], "positive": {"value": "positive", "index": 1}}}
probability_multi = [[0.85, 0.75]]
config_multi = {"labels": {"values": ["b117", "b130"]}}

MSG_RUNTIME_ERROR_CAUSE = "Application suddenly stopped working"


class MockModelFacadeSingle:

    def predict(self, str):
        return probability_single

    def get_config(self):
        return ModelConfig(config_single)

    def get_model_source(self):
        return "mock:single:1.0.0"


class MockModelFacadeMulti:

    def predict(self, str):
        return probability_multi

    def get_config(self):
        return ModelConfig(config_multi)

    def get_model_source(self):
        return "mock:multi:1.0.0"


class MockModelFacadePredictRaise:
    def predict(self, str):
        raise RuntimeError(MSG_RUNTIME_ERROR_CAUSE)


def model_facade_get_model_single(self, config_id):
    return MockModelFacadeSingle()


def model_facade_get_model_multi(self, config_id):
    return MockModelFacadeMulti()


def model_facade_get_model_raise(self, config_id):
    raise ModelNotFoundException


def model_facade_get_model_predict_raise(self, config_id):
    return MockModelFacadePredictRaise()


def get_prediction_url(config_id):
    # TODO: This should be replaced with a URI Template RFC6570, requested library to nexus
    return '/prediction?configId=' + config_id


class TestApp(TestCase):

    def test_entrypoint_contains_predict_relationship(self):
        # given:
        expected = EntryPointRepresentation.get()

        # when:
        response = app.test_client().get('/', content_type='application/hal+json')

        # then:
        assert response.status_code == 200
        actual = json.loads(response.get_data(as_text=True))
        assert actual == expected

    @mock.patch.object(ModelFacadeFactory, 'get_model', model_facade_get_model_raise)
    def test_prediction_model_not_exists(self):
        # when:
        response = app.test_client().post(
            get_prediction_url(configId),
            data=json.dumps(jsonData),
            content_type='application/json',
        )

        # then:
        assert response.status_code == 404
        result = json.loads(response.get_data(as_text=True))
        assert result['message'] == ERROR_MSG_MODEL_NOT_EXISTS.format(configId)

    def test_prediction_missing_text_input(self):
        # when:
        response = app.test_client().post(
            get_prediction_url(configId),
            data=json.dumps({}),
            content_type='application/json',
        )

        # then:
        assert response.status_code == 400
        result = json.loads(response.get_data(as_text=True))
        assert result['message'] == ERROR_MSG_TEXT_EMPTY

    @mock.patch.object(ModelFacadeFactory, 'get_model', model_facade_get_model_predict_raise)
    def test_prediction_model_throws_env_error(self):
        # when:
        response = app.test_client().post(
            get_prediction_url(configId),
            data=json.dumps(jsonData),
            content_type='application/json',
        )

        # then:
        assert response.status_code == 500
        result = json.loads(response.get_data())
        assert MSG_RUNTIME_ERROR_CAUSE in result['message']

    @mock.patch.object(ModelFacadeFactory, 'get_model', model_facade_get_model_single)
    def test_prediction_model_single(self):
        # when:
        response = app.test_client().post(
            get_prediction_url(configId),
            data=json.dumps(jsonData),
            content_type='application/json',
        )

        # then:
        assert response.status_code == 200
        result = json.loads(response.get_data(as_text=True))
        meta = result['meta']
        text = result['text']
        labels = result['labels']
        assert meta['config'] == configId
        assert meta['version'] == '0.0.1'
        assert text == jsonData['text']
        positive_label_index = config_single.get('labels').get('positive').get('index')

        assert labels[0]['name'] == configId
        assert labels[0]['type'] == "icf-koder"
        assert labels[0]['probability'] == probability_single[0][positive_label_index]
        assert labels[0]['source'] == "mock:single:1.0.0"

    @mock.patch.object(ModelFacadeFactory, 'get_model', model_facade_get_model_multi)
    def test_prediction_model_multi(self):
        # when:
        response = app.test_client().post(
            get_prediction_url(configId),
            data=json.dumps(jsonData),
            content_type='application/json',
        )

        # then:
        assert response.status_code == 200
        result = json.loads(response.get_data(as_text=True))
        meta = result['meta']
        text = result['text']
        labels = result['labels']
        assert meta['config'] == configId
        assert meta['version'] == '0.0.1'
        assert text == jsonData['text']

        assert labels[0]['name'] == config_multi['labels']['values'][0]
        assert labels[0]['type'] == "icf-koder"
        assert labels[0]['probability'] == probability_multi[0][0]
        assert labels[0]['source'] == "mock:multi:1.0.0"

        assert labels[1]['name'] == config_multi['labels']['values'][1]
        assert labels[1]['type'] == "icf-koder"
        assert labels[1]['probability'] == probability_multi[0][1]
        assert labels[1]['source'] == "mock:multi:1.0.0"