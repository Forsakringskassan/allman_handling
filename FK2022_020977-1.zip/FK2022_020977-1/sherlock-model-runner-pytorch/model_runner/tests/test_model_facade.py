from unittest import TestCase
from unittest import mock

import pytest

from model_runner.model_facade import ModelFacade
from model_runner.model_facade import ModelFacadeFactory
from model_runner.model_facade import ModelNotFoundException

prediction = [0]
probability = [[0.9114453196525574, 0.08855472505092621]]
path_to_models = "data/model"
base_model_name = "bert-base-cased"
config_id = "d220"
model_file_name = "best_model.pt"
device = "cpu"
encoding = "utf-8"
input_ids = [2, 45032, 155, 1426, 748, 12423, 36, 25515, 22642, 1074, 48, 9736, 2859, 13046, 7, 3, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
             0, 0, 0, 0, 0, 0, 0, 0, 0]
attention_mask = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0, 0, 0]


class MockModel:

    def predict(self, texts, masks):
        return prediction, probability

def mock_text_to_int(self, sentence):
    return input_ids, attention_mask


class TestModelFacade(TestCase):

    @mock.patch("sherlock_common.text_transform.TextTransform.__init__", return_value=None)
    def test_model_facade_throws_TypeError(self, mock_text_transform):
        # given:
        input = 123

        # when:
        instance = ModelFacade(path_to_models, config_id, device)

        # then:
        with pytest.raises(TypeError):
            instance.predict(input)

    @mock.patch("sherlock_common.text_transform.TextTransform.__init__", return_value=None)
    @mock.patch("sherlock_common.text_transform.TextTransform.text_to_int", mock_text_to_int)
    def test_prediction_function(self, mock_text_transform):
        # given:
        text = "predict me"
        model_path = "data/model"
        instance = ModelFacade(model_path, config_id, device)
        instance._model = MockModel()

        # when:
        actual_prediction, actual_probability = instance.predict(text)

        # then:
        assert actual_probability == probability
        assert actual_prediction == prediction