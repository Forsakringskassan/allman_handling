import logging
import os

from flask import Flask, abort, request, make_response
from flask_restful import Resource, Api, reqparse
from prometheus_client import make_wsgi_app
from werkzeug.middleware.dispatcher import DispatcherMiddleware

from model_runner.model_facade import ModelFacadeFactory
from model_runner.model_facade import ModelNotFoundException
from model_runner.representation import EntryPointRepresentation

app = Flask(__name__)
# Add prometheus wsgi middleware to route /metrics requests
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/metrics': make_wsgi_app()
})
app.config['JSON_AS_ASCII'] = False
api = Api(app)

# Set logging level
logger = logging.getLogger(__name__)

DEFAULT_MODEL_PATH = os.getenv('DEFAULT_MODEL_PATH') if os.getenv('DEFAULT_MODEL_PATH') else os.path.join(os.getcwd(),
                                                                                                          'data',
                                                                                                          'model')
HOST_BIND_IP = os.getenv('HOST_BIND_IP') if os.getenv('HOST_BIND_IP') else '0.0.0.0'
HOST_BIND_PORT = os.getenv('HOST_BIND_PORT') if os.getenv('HOST_BIND_PORT') else 9990
DEBUG = os.getenv('DEBUG') if os.getenv('DEBUG') else False
MAX_LEN = 128
DEVICE = 'cpu'
ERROR_MSG_MODEL_NOT_EXISTS = 'No model exists for: {}'
ERROR_MSG_RUNNING_MODEL = 'Error occurred when running model, cause: {}'
ERROR_MSG_TEXT_EMPTY = 'Missing text as input'
MIME_TYPE_HAL_JSON = 'application/hal+json'

model_factory = ModelFacadeFactory(DEFAULT_MODEL_PATH, DEVICE, MAX_LEN)


class App(Resource):

    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('text')
        args = parser.parse_args()
        text = args['text']
        if not text:
            abort(400, ERROR_MSG_TEXT_EMPTY)

        config_id = request.args['configId']

        try:
            model_facade = model_factory.get_model(config_id)
            probs = model_facade.predict(text)[0]
            config = model_facade.get_config()
            if not config.is_binary_classifier():
                label_names = config.get_label_values()
                labels = [{"name": id, "type": config.get_label_type(), "probability": prob,
                           "source": model_facade.get_model_source()}
                          for id, prob in zip(label_names, probs)]
            else:
                pos_index = config.get_positive_index()
                labels = [{'name': config_id, 'type': config.get_label_type(), 'probability': probs[pos_index],
                           'source': model_facade.get_model_source()}]
            result = {
                'meta': {
                    'config': config_id,
                    'version': "0.0.1"
                },
                'text': text,
                'labels': labels
            }
            response = make_response(result)
            response.headers['Content-type'] = 'application/json; charset=utf-8'
            return response
        except ModelNotFoundException:
            abort(404, ERROR_MSG_MODEL_NOT_EXISTS.format(config_id))
        except (RuntimeError, TypeError, EnvironmentError) as error:
            abort(500, ERROR_MSG_RUNNING_MODEL.format(error))


@app.route("/")
def index():
    result = EntryPointRepresentation().get()
    response = make_response(result)
    response.mimetype = MIME_TYPE_HAL_JSON
    return response


@app.route("/health", methods=["GET"])
def health():
    return "Running sherlock-model-runner-pytorch"


api.add_resource(App, '/prediction')


def run():
    app.run(host=HOST_BIND_IP, port=HOST_BIND_PORT, debug=DEBUG)
