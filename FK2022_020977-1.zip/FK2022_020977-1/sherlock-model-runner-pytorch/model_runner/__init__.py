import logging.config
from pathlib import Path

import yaml

log_config_yaml = Path(__file__).resolve().parent / 'logging-config.yaml'

with open(log_config_yaml, 'rt') as f:
    config = yaml.safe_load(f.read())
logging.config.dictConfig(config)
logger = logging.getLogger(__name__)