import logging
import os
from functools import lru_cache

import torch
from sherlock_common.model_functions import load_pretrained_model
from sherlock_common.text_transform import TextTransform

logger = logging.getLogger(__name__)

class ModelFacade:
    """
    To use this class, instantiate the facade and run :func:`:load` followed up by :func:`:predict` to get a prediction.
    """
    _model = None
    _config = None
    _source = None

    def __init__(self,
                 path_to_model,
                 config_id,
                 source,
                 device='cpu',
                 max_len=128,
                 ):
        self._model_path = path_to_model
        self._transformer = create_text_transform(self._model_path, max_len)
        self._device = device
        self._source = source

    def load(self):
        self._model, config = load(self._device, self._model_path)
        self._config = ModelConfig(config)

    def predict(self, text):
        if not isinstance(text, str):
            raise TypeError("The input should be a string.")

        input_ids, attention_mask = self._transformer.text_to_int(text)

        texts = torch.tensor([input_ids]).to(self._device)
        masks = torch.tensor([attention_mask]).to(self._device)

        with torch.no_grad():
            probability = self._model.predict(texts, masks)
        return probability

    def get_config(self):
        return self._config

    def get_model_source(self):
        return self._source


class ModelConfig:
    _json = None
    _label_type = "icf-koder"

    def __init__(self, json):
        self._json = json

        type = self._json.get('labels').get('type')
        if type is not None:
            self._label_type = type

    def get_label_type(self):
        return self._label_type

    def get_label_values(self):
        return self._json.get('labels').get('values')

    def is_binary_classifier(self):
        return self._json.get('labels').get('positive') is not None

    def get_positive_index(self):
        return self._json.get('labels').get('positive').get('index')


@lru_cache(maxsize=1)
def create_text_transform(path, length):
    return TextTransform(path, length)


def load(device, path):
    model, _, config = load_pretrained_model(path)

    logger.info("torch.get_num_threads()={}".format(torch.get_num_threads()))
    quantization_enabled = os.getenv('QUANTIZATION_ENABLED', 'False') in ('True', 'true')
    quantization_type = int(os.getenv('QUANTIZATION_TYPE', '8'))
    logger.info("QUANTIZATION_ENABLED={}".format(quantization_enabled))
    if quantization_enabled:
        config_spec = {torch.nn.Linear}
        if device == 'cpu':
            dtype = torch.qint8
            if quantization_type == 16:
                dtype = torch.float16
            logger.info("Running Quantization {} {}".format(path, dtype))
            model = torch.quantization.quantize_dynamic(model, config_spec, dtype=dtype)

    model.eval()
    return model, config


class ModelNotFoundException(Exception):
    """Model not found exception"""
    pass


class ModelFacadeFactory:
    """
    Factory pattern for creating model objects.
    """
    _models = None

    def __init__(self, models_path, device="cpu", max_len=128):
        self._models_path = models_path
        self._device = device
        self._max_len = max_len

    def _find_models(self):
        if self._models is None:
            logger.info("Available model, empty, searching...")
            temp = {}
            groups = os.listdir(self._models_path)
            for group in groups:
                names = os.listdir(self._models_path.__str__() + "/" + group)
                for name in names:
                    versions = os.listdir(self._models_path.__str__() + "/" + group + "/" + name)
                    for version in versions:
                        temp[name] = {'source': group.__str__() + ":" + name.__str__() + ":" + version.__str__(),
                                      'path': self._models_path.__str__() + "/" + group.__str__() + "/" + name.__str__() + "/" + version.__str__()}
            self._models = temp
            logger.info("Found model {}".format(self._models))
        return self._models

    @lru_cache(maxsize=21)
    def get_model(self, config_id):
        try:
            model_facade = ModelFacade(self.get_model_path(config_id), config_id, self.get_model_source(config_id), self._device, self._max_len)
            model_facade.load()
            return model_facade
        except (ValueError, KeyError):
            raise ModelNotFoundException

    def get_models(self):
        # get all the model found.
        self._find_models()
        return self._models

    def get_model_source(self, config_id):
        # get the source from the map.
        return self.get_models()[config_id]['source']

    def get_model_path(self, config_id):
        # get the path from the map
        return self.get_models()[config_id]['path']

