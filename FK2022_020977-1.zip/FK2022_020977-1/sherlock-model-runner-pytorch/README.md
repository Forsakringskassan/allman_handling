# Sherlock-model-runner-pytorch

## Prerequisites

The things you need to install and how to install them

  * Python version 3.8.2

Installing for development

### Install python dependencies locally
```
pip3 install -i <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
     --extra-index-url <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
     --trusted-host <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > -r requirements/dev-qa.txt
```

### Requirements

Sherlock-model-runner-pytorch needs at least one pre trained model in order to run a prediction on some text.

Models should be in a <group>/<name>/<version> folder structure under the "model" folder.

The following is an enable of the structure with 1 model for se.fk.kog.sherlock:d220:1.0.0:

```sh
/data
├── model
│   ├── se.fk.kog.sherlock
│   |   ├── d220
|   |   │   ├── 1.0.0
|   |   │   │   ├── best_model.pt
|   |   │   │   ├── vocab.txt
|   |   │   │   ├── config.json
```

##### Environment variables:
* DEFAULT_MODEL_PATH
    * Path to folder with models. Default is ```/data/model```
* HOST_BIND_IP
    * Default is '0.0.0.0'
* HOST_BIND_PORT
    * Default is 9990
* DEBUG 
    * Default is False

## Running application

```
python -m model_runner
```

## Run tests
Run unit tests with `pytest` and integration tests with `pytest model_runner/integration -rA`

## Input and Output for API

### Input example 

```
curl -X POST -H "Content-type: application/json" --data "{\"text\":\"Kognitiv uttrottbarhet och nedsatt formaga att fa saker gjorda.\"}" http://localhost:9990/prediction?configId=d220
```

### Output example 
#### Single label example 
```
{
    "meta": {
        "config": "d220",
        "version": "0.0.1"
    },
    "text": "Kognitiv uttrottbarhet och nedsatt formaga att fa saker gjorda.",
    "labels": [{
        "name": "d220",
        "type": "icf-code",
        "probability": 0.1061687245965004,
        "source": "d220"
    }]
}
```
#### Multi-labels example
```
{
    "meta": {
        "config": "all",
        "version": "0.0.1"
    },
    "text": "Kognitiv uttrottbarhet och nedsatt formaga att fa saker gjorda.",
    "labels": [{"name": "0", "probability": 8.642736247566063e-06, "source": "all", "type": "icf-code"},
               {"name": "1", "probability": 9.230095201928634e-06, "source": "all", "type": "icf-code"},
               {"name": "2", "probability": 4.710882876679534e-06, "source": "all", "type": "icf-code"},
               {"name": "3", "probability": 1.6059728295658715e-05, "source": "all", "type": "icf-code"},
               {"name": "4", "probability": 1.7307741018157685e-06, "source": "all", "type": "icf-code "},
               {"name": "8", "probability": 0.9999573230743408, "source": "all", "type": "icf-code"},
               {"name": "9", "probability": 2.232460701634409e-06, "source": "all", "type": "icf-code"}]
}
```
## Metrics

sherlock-model-runner-pytorch uses [prometheus_client](https://github.com/prometheus/client_python) to get metrics.

Prometheus_client supports cpu and memory metrics on Linux and is currently the only metrics measured in the application.
Own metrics can be added but there are some quirks regarding this when using gunicorn with workers. In order to get metrics
from all workers, a common directory must be used that is set by the env: ```prometheus_multiproc_dir```. 
This env is set in the pod of sherlock-model-runner-pytorch.

However, each time a worker restart (which also happens with only one worker) a new db file gets created for the summarized 
metrics. Over time, many db files will be created but never deleted which may impact the metric collecting performance.
The problem is in more detail described [here](https://medium.com/@weastur/serving-prometheus-metrics-from-gunicorn-987793946ab3)

## Non Functional

With the current configuration it is possible to fit 21 models into memory with roughly 1Gb working memory for requests.
Models are lazy loaded with an lru_cache equal to the number of models.
A single worker is also used to ensure the lru_cache is not recreated by each of the workers therefore requiring the models to be loaded again for each worker.
Only 2 threads are used with the current 2 CPU setup - this is less than normal recommendation of 5 (2*num cpu +1) due to increased memory overhead experience with more threads resulting in not being able to fit all 21 models.
The readiness and liveness probe timeouts have been increased to 120 seconds to prevent erroneous restarts due to failed probe request under load.

### Testing
Test with sentence lengths and concurrent requests have been performed.
Sentence length does not seem to make any different in performance, as see previously with other models.
Number of concurrent requests is limited to 2 due to the gunicorn thread settings, however tests with up to 100 concurrent users have been performance and show stable linear growth.

Non functional tests are run using jmeter as a gradle plugin.

### Further work
There are further optimisations available, e.g. 
* Use of more CPU
* Use of GPU
* TextTransform reuse between similar models. 
* Request caching.
* Sentence encoding caching.
* etc 