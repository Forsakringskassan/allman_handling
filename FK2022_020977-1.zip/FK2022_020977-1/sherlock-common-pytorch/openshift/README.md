# Openshift

Run the following command to create the pipeline from the build-config.yaml.

Then run this pipeline and it will in turn create the rest.

```commandline
git update-index --chmod=+x gradlew
```
NB - if this command fails, try typing it manually, rather than copy and paste.

```commandline
cd openshift
oc process jenkins-pipeline --param-file=build.properties -o=yaml| oc apply -f -
```