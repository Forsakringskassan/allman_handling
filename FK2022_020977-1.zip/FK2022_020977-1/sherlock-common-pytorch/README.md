# Install requirements.txt
```
pip3 install -i <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
     --extra-index-url <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > \
    --trusted-host <borttaget enligt 18 kap. 8 offentlighets- och sekretesslagen (2009:400) > -r requirements.txt
```

# Common library for pytorch
This repo contains the common tools and functions for SKOSAs inference and training. This is used to create 
modules and upload them to nexus.


# How does this work?
dist folder is created by running `python sherlock_common/setup.py sdist bdist_wheel --universal`. 
This creates whl files and a tar.gz. 

A wheel file contains four variables: `<PACKAGE_NAME>-<VERSION>-<OS>-<ARCHITECTURE>.whl`
An example of a wheel-file is `sherlock_common-0.0.1-py3-none-any.whl`.

 `py3`, `none` and `any`, which means that its only compatible with python3, it's
__NONE__-specific to an operative system and is suitable to run on __ANY__ processor architecture.

# How do I apply my changes?
Update version in both `version.properties` and `sherlock_common/setup.py` 
before running the pipeline. See [openshift/README.md](openshift/README.md).

