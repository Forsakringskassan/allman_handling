import logging
import os

import torch
import torch.nn as nn
from transformers import BertModel, BertConfig

logger = logging.getLogger(__name__)

MSG_CONFIG_NO_EXISTS = 'Config file does not exist.'
MSG_BASE_MODEL_NO_EXISTS = 'Base model file does not exist.'
MSG_INPUT_ID_NO_EXISTS = 'Input id (integer tensor) does not exist.'
MSG_MASK_NO_EXISTS = 'Attention mask (list of 1/0 tensor) does not exist.'
MSG_DIMENSION_WRONG = 'Attention mask does not have the same dimension as input_ids.'
MSG_OUTPUT_ACTIVATION_NO_SUPPORT = 'Current version only support softmax and sigmoid.'
SOFTMAX = "softmax"
SIGMOID = "sigmoid"


class Model(nn.Module):
    def __init__(self, model_path, num_label, type=None):
        r"""Build a Bert classification model
        :arg
        model_path: the path to the pre_trained or pre_defined model
        type: "base", None
        """
        super().__init__()
        self.validate_config(model_path)
        self.config = BertConfig.from_pretrained(model_path)
        self.bert = self.get_base_model(type, model_path)
        self.dropout = nn.Dropout(self.config.hidden_dropout_prob)
        self.classifier = nn.Linear(self.config.hidden_size, num_label)

    def predict(self, input_ids=None, attention_mask=None, output_activation_type="softmax"):
        self.validate_input(input_ids, attention_mask)
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        pooled_output = outputs[1]
        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)
        if output_activation_type == SOFTMAX:
            y_prob = torch.nn.functional.softmax(logits, 1).tolist()
        elif output_activation_type == SIGMOID:
            y_prob = torch.sigmoid(logits).tolist()
        else:
            logger.error(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)
            raise ValueError(MSG_OUTPUT_ACTIVATION_NO_SUPPORT)
        return y_prob

    def forward(self, input_ids=None, attention_mask=None):
        r"""
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size,)`, `optional`, defaults to :obj:`None`):
            Labels for computing the sequence classification/regression loss.
            Indices should be in :obj:`[0, ..., config.num_labels - 1]`.
            If :obj:`config.num_labels == 1` a regression loss is computed (Mean-Square loss),
            If :obj:`config.num_labels > 1` a classification loss is computed (Cross-Entropy).
        """
        self.validate_input(input_ids, attention_mask)
        outputs = self.bert(
            input_ids,
            attention_mask=attention_mask
        )
        pooled_output = outputs[1]

        pooled_output = self.dropout(pooled_output)
        logits = self.classifier(pooled_output)

        return logits

    @staticmethod
    def validate_config(model_path):
        if not os.path.exists(os.path.join(model_path, 'config.json')):
            logger.error(MSG_CONFIG_NO_EXISTS)
            raise ValueError(MSG_CONFIG_NO_EXISTS)

    @staticmethod
    def validate_input(input_ids, attention_mask):
        if input_ids is None:
            logger.error(MSG_INPUT_ID_NO_EXISTS)
            raise ValueError(MSG_INPUT_ID_NO_EXISTS)
        if attention_mask is None:
            logger.error(MSG_MASK_NO_EXISTS)
            raise ValueError(MSG_MASK_NO_EXISTS)
        if input_ids.shape != attention_mask.shape:
            logger.error(MSG_DIMENSION_WRONG)
            raise ValueError(MSG_DIMENSION_WRONG)

    def get_base_model(self, type, model_path):
        if type == "base":
            if not os.path.exists(os.path.join(model_path, 'pytorch_model.bin')):
                logger.error(MSG_BASE_MODEL_NO_EXISTS)
                raise ValueError(MSG_BASE_MODEL_NO_EXISTS)
            return BertModel.from_pretrained(model_path)
        else:
            return BertModel(self.config)
