import logging
import os

from transformers import BertTokenizer

logger = logging.getLogger(__name__)

MSG_VOC_NO_EXISTS = 'Vocabulary does not exist for tokenizer in the pre_trained_model path.'
MSG_VOC_FILE_WRONG = 'The content of the vocabulary file is not correct.'
MSG_TRAINED_MODEL_NO_EXISTS = 'Pre-trained model does not exist.'


class TextTransform:
    """Map the text to integers"""

    def __init__(self, base_model_path, max_len=128, do_lower_case=True):
        self.tokenizer = None
        self.base_model_path = base_model_path
        self.do_lower_case = do_lower_case
        self.max_len = self._get_max_length(max_len)
        self.tokenizer = self._create_tokenizer()

    def text_to_int(self, sentence):
        """Map the text to integers and output attention_masks"""
        temp_token = ['[CLS]'] + self.tokenizer.tokenize(sentence)

        if len(temp_token) > self.max_len - 1:
            temp_token = temp_token[:self.max_len - 1]
            temp_token = temp_token + ['[SEP]']
        else:
            temp_token = temp_token + ['[SEP]']
            temp_token += ['[PAD]'] * (self.max_len - len(temp_token))
        input_ids = self.tokenizer.convert_tokens_to_ids(temp_token)
        attention_masks = [int(i > 0) for i in input_ids]

        return input_ids, attention_masks

    def _create_tokenizer(self):
        try:
            vocabulary = get_vocabulary(self.base_model_path)
            return BertTokenizer(vocab_file=vocabulary, do_lower_case=self.do_lower_case)
        except:
            logger.error(MSG_VOC_FILE_WRONG)
            raise ValueError(MSG_VOC_FILE_WRONG)

    def _get_max_length(self, max_len):
        if not isinstance(max_len, int) or max_len > 128:
            return 128
        else:
            return max_len


def get_vocabulary(base_model_path):
    if not os.path.exists(base_model_path):
        logger.error(MSG_TRAINED_MODEL_NO_EXISTS)
        raise ValueError(MSG_TRAINED_MODEL_NO_EXISTS)

    vocabulary = os.path.join(base_model_path, "vocab.txt")
    if os.path.exists(vocabulary):
        return vocabulary
    else:
        logger.error(MSG_VOC_NO_EXISTS)
        raise ValueError(MSG_VOC_NO_EXISTS)
