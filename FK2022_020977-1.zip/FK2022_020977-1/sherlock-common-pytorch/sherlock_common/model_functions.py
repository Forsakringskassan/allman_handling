import json
import logging
import os

import torch
import torch.nn as nn
from sherlock_common.model import Model

logger = logging.getLogger(__name__)

MSG_MODEL_NO_EXISTS = 'Model file does not exist.'
MSG_MODEL_STATE_NO_EXISTS = 'The saved model does not have model_state_dict inside.'
MSG_MODEL_WRONG_STRUCTURE = 'The model saved is build with the different structure.'
MSG_CONFIG_NO_EXISTS = 'Config file does not exist.'


def save_trained_model(save_path, model, model_name, valid_loss, device):
    save_path = os.path.join(save_path, model_name + '.pt')
    if device == 'cuda':
        state_dict = {'model_state_dict': model.to('cpu').state_dict(),
                      'valid_loss': valid_loss}
        model.to(device)
    else:
        state_dict = {'model_state_dict': model.state_dict(),
                      'valid_loss': valid_loss}
    torch.save(state_dict, save_path)


def load_pretrained_model(model_path):
    model_file_path = validate_model_path(model_path)
    config_file_path = validate_config_path(model_path)
    with open(config_file_path) as json_file:
        config_file = json.load(json_file)
    num_label = config_file['num_label']
    model = Model(model_path, num_label)
    model_dict = get_dictionary(model_file_path)
    load_weights(model, model_dict['model_state_dict'])
    return model, model_dict['valid_loss'], config_file


def load_weights(model, model_dict):
    try:
        model.load_state_dict(model_dict)
    except:
        logger.error(MSG_MODEL_WRONG_STRUCTURE)
        raise ValueError(MSG_MODEL_WRONG_STRUCTURE)


def get_dictionary(model_file_path):
    try:
        model_dict = torch.load(model_file_path)
        model_dict = model_dict
    except:
        logger.error(MSG_MODEL_STATE_NO_EXISTS)
        raise ValueError(MSG_MODEL_STATE_NO_EXISTS)
    return model_dict


def validate_model_path(model_path):
    model_file_path = os.path.join(model_path, 'best_model.pt')
    if not os.path.exists(model_file_path):
        logger.error(MSG_MODEL_NO_EXISTS)
        raise ValueError(MSG_MODEL_NO_EXISTS)
    return model_file_path


def validate_config_path(model_path):
    config_file_path = os.path.join(model_path, 'config.json')
    if not os.path.exists(config_file_path):
        logger.error(MSG_CONFIG_NO_EXITS)
        raise ValueError(MSG_CONFIG_NO_EXITS)
    return config_file_path
