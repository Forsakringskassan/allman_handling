import os
from unittest import TestCase

import pytest
from sherlock_common.text_transform import TextTransform
from sherlock_common.text_transform import get_vocabulary
from transformers import BertTokenizer


def get_wrong_vocab_file():
    return os.path.join(pytest.DEFAULT_MODEL_PATH, "wrong_vocab_file.txt")


class TestTextTransform(TestCase):
    def test_class_inputs(self):
        """ test the input to intial the TextTransform class"""
        transformer = TextTransform(base_model_path=pytest.DEFAULT_MODEL_PATH, max_len=200)
        vocabulary = os.path.join(pytest.DEFAULT_MODEL_PATH, "vocab.txt")
        tokenizer = BertTokenizer(vocab_file=vocabulary, do_lower_case=True)
        assert tokenizer.__eq__(transformer.tokenizer)
        assert transformer.max_len == 128

        transformer = TextTransform(base_model_path=pytest.DEFAULT_MODEL_PATH, max_len=100, do_lower_case=False)
        tokenizer = BertTokenizer(vocab_file=vocabulary, do_lower_case=True)
        assert transformer.max_len == 100
        assert tokenizer.__eq__(transformer.tokenizer)

        transformer = TextTransform(base_model_path=pytest.DEFAULT_MODEL_PATH, max_len='hi')
        tokenizer = BertTokenizer(vocab_file=vocabulary, do_lower_case=True)
        assert transformer.max_len == 128
        assert tokenizer.__eq__(transformer.tokenizer)

        with pytest.raises(ValueError):
            transformer = TextTransform(base_model_path=pytest.MODEL_PATH_NO_EXIST)
            transformer.text_to_int("boom")

    def test_get_vocabulary_throws_value_error(self):
        expected = os.path.join(pytest.DEFAULT_MODEL_PATH, "vocab.txt")
        actual = get_vocabulary(pytest.DEFAULT_MODEL_PATH)

        assert actual == expected

        with pytest.raises(ValueError):
            get_vocabulary(pytest.MODEL_PATH_NO_VOC)

    def test_text_to_int(self):
        """ test the function to process the text to integer and output mask"""
        transformer = TextTransform(base_model_path=pytest.DEFAULT_MODEL_PATH)
        input_id, mask = transformer.text_to_int(pytest.TEXT_INPUT)
        assert input_id == pytest.TEXT_INPUT_IDS
        assert mask == pytest.TEXT_MASK
        assert len(input_id) == pytest.MAX_LEN
        input_id_without_padding = [i for i in input_id if i != 0]
        mask_without_padding = [i for i in mask if i != 0]
        assert len(input_id_without_padding) == pytest.TEXT_TOKEN_LEN
        assert len(mask_without_padding) == pytest.TEXT_TOKEN_LEN

        input_id, mask = transformer.text_to_int(pytest.LONG_TEXT)
        assert len(input_id) == pytest.MAX_LEN
        assert len(mask) == pytest.MAX_LEN
        assert len(set(mask)) == 1
        assert list(set(mask))[0] == 1

        max_len = 100  ## smaller than the text itself
        transformer = TextTransform(base_model_path=pytest.DEFAULT_MODEL_PATH, max_len=max_len)
        input_id, mask = transformer.text_to_int(pytest.LONG_TEXT)
        assert len(input_id) == max_len
        assert len(mask) == max_len
        assert len(set(mask)) == 1
        assert list(set(mask))[0] == 1
        assert input_id[0] == 2
        assert input_id[-1] == 3
