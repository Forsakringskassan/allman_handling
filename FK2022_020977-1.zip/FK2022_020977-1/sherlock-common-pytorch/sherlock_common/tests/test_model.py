import json
import os
import pdb
from collections import OrderedDict
from unittest import TestCase

import pytest
import torch
import torch.nn as nn
from transformers.modeling_outputs import BaseModelOutputWithPastAndCrossAttentions, \
    BaseModelOutputWithPoolingAndCrossAttentions

from sherlock_common.model import Model


class SaveInterLayers:
    middle_layers = []

    def __init__(self, model):
        self.hooks = []
        for module in model.modules():
            if not isinstance(module, nn.Sequential) and not isinstance(module, nn.ModuleList):
                self.hooks.append(module.register_forward_hook(self.hook))

    def hook(self, module, input, output):
        module_idx = len(self.middle_layers)
        class_name = str(module.__class__).split(".")[-1].split("'")[0]
        m_key = "%s-%i" % (class_name, module_idx + 1)

        if m_key:
            self.middle_layers[m_key] = OrderedDict()
            if len(input) != 0:
                self.middle_layers[m_key]["input_shape"] = list(input[0].size())
            else:
                self.middle_layers[m_key]['input_shape'] = 0

            if isinstance(output, (list, tuple)):
                self.middle_layers[m_key]["output_shape"] = [
                    [-1] + list(o.size())[1:] for o in output
                ]
            elif not isinstance(output, BaseModelOutputWithPastAndCrossAttentions):
                if not isinstance(output, BaseModelOutputWithPoolingAndCrossAttentions):
                    self.middle_layers[m_key]["output_shape"] = list(output.size())

    def remove(self):
        for hook in self.hooks:
            hook.remove()


class TestModel(TestCase):
    def test_default_input(self):
        with pytest.raises(ValueError):
            Model.validate_config(model_path=pytest.MODEL_PATH_NO_VOC)

        with pytest.raises(ValueError):
            Model.validate_input(input_ids=None, attention_mask=torch.tensor([pytest.TEXT_MASK]))

        with pytest.raises(ValueError):
            Model.validate_input(input_ids=torch.tensor([pytest.TEXT_INPUT_IDS]), attention_mask=None)

        with pytest.raises(ValueError):
            input_id = pytest.TEXT_INPUT_IDS[:-1]
            Model.validate_input(input_ids=torch.tensor([input_id]), attention_mask=torch.tensor([pytest.TEXT_MASK]))

        with pytest.raises(ValueError):
            Model(model_path=pytest.DEFAULT_MODEL_PATH, num_label=pytest.NUM_LABEL, type='base')

    def test_model(self):
        texts, masks, labels = pytest.TEXTS_INPUT, pytest.MASKS_INPUT, pytest.LABELS_INPUT
        texts, masks, labels = texts.to(pytest.DEVICE), masks.to(pytest.DEVICE), labels.to(pytest.DEVICE)
        model = Model(model_path=pytest.DEFAULT_MODEL_PATH, num_label=pytest.NUM_LABEL)

        hook = SaveInterLayers(model)
        hook.middle_layers = OrderedDict()
        model(input_ids=texts, attention_mask=masks)
        hook.remove()

        # compare the output with the config.json
        with open(os.path.join(pytest.DEFAULT_MODEL_PATH, 'config.json')) as f:
            params = json.load(f)
        hidden_size = params['hidden_size']
        intermediate_size = params['intermediate_size']
        num_hidden_layers = params['num_hidden_layers']
        num_attention_heads = params['num_attention_heads']

        assert hook.middle_layers['Embedding-1']['input_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Embedding-1']['input_shape'][1] == pytest.MAX_LEN
        assert hook.middle_layers['Embedding-1']['output_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Embedding-1']['output_shape'][1] == pytest.MAX_LEN
        assert hook.middle_layers['Embedding-1']['output_shape'][2] == hidden_size

        assert hook.middle_layers['Dropout-10']['input_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Dropout-10']['input_shape'][1] == num_attention_heads
        assert hook.middle_layers['Dropout-10']['input_shape'][2] == pytest.MAX_LEN
        assert hook.middle_layers['Dropout-10']['input_shape'][3] == pytest.MAX_LEN

        assert hook.middle_layers['Linear-17']['output_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Linear-17']['output_shape'][1] == pytest.MAX_LEN
        assert hook.middle_layers['Linear-17']['output_shape'][2] == intermediate_size

        assert hook.middle_layers['Linear-19']['input_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Linear-19']['input_shape'][1] == pytest.MAX_LEN
        assert hook.middle_layers['Linear-19']['input_shape'][2] == intermediate_size

        assert hook.middle_layers['Model-218']['output_shape'][0] == pytest.BATCH_SIZE
        assert hook.middle_layers['Model-218']['output_shape'][1] == pytest.NUM_LABEL

        hidden_layers = 0
        for layer in hook.middle_layers:
            if layer.split('-')[0] == 'BertSelfAttention':
                hidden_layers += 1
        assert hidden_layers == num_hidden_layers

    def test_model_predict(self):
        """Test the method in Model class to predict."""
        text, mask = pytest.TEXTS_INPUT, pytest.MASKS_INPUT
        text = text.to(pytest.DEVICE)
        mask = mask.to(pytest.DEVICE)

        model = Model(model_path=pytest.DEFAULT_MODEL_PATH, num_label=pytest.NUM_LABEL)

        predictions = model.predict(text, mask, output_activation_type='softmax')

        assert round(sum(predictions[0]), 6) == 1
        assert round(sum(predictions[1]), 6) == 1

        predictions = model.predict(text, mask, output_activation_type='softmax')

        assert all(i <= 1 for i in predictions[0])
        assert all(i <= 1 for i in predictions[1])
