from unittest import TestCase
from unittest import mock

import pytest
import torch
import torch.nn as nn
from sherlock_common.model_functions import load_pretrained_model
from torch.utils import data

state_dict_right_structure_no_value = {'model_state_dict': {'fake_Weights': 0}, 'valid_loss': 0}
state_dict_wrong_structure_1 = {'model_state': {'fake_Weights': 0}, 'valid_loss': 0}
state_dict_wrong_structure_2 = {'model_state_dict': None}
state_dict_wrong_structure_3 = None


@pytest.mark.parametrize("input_state_dict", [state_dict_right_structure_no_value, state_dict_wrong_structure_1,
                                              state_dict_wrong_structure_2, state_dict_wrong_structure_3])
def test_load_pretrained_model_throws_value_error(input_state_dict):
    mock.patch(
        'torch.load',
        return_value=input_state_dict
    )
    with pytest.raises(ValueError):
        load_pretrained_model(pytest.DEFAULT_MODEL_PATH)
