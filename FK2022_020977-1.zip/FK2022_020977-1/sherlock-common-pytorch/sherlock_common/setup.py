from setuptools import setup, find_packages

setup(
    name='sherlock_common',
    version='0.0.8',
    packages=find_packages(),
    url='',
    license='',
    author='LO KOG',
    author_email='',
    description='Common tools and functions for machine learning related services'
)
